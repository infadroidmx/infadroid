import xbmc as O0OO0OOOOO000O00O ,xbmcaddon as OO00OO0OO00O00000 ,xbmcgui as O00O00OO0O0O0OO00 ,xbmcplugin as OOOOO0000O00OOOOO ,os as O000OO00O00OOOO00 ,base64 as OO00OOOOO0O000OO0 ,sys as OO0000OO0OO00OO0O ,xbmcvfs as OO000O00OOO00O0OO #line:1
import shutil as O0O0O0O0O000000O0 #line:2
import urllib2 as OO0OOOOO0000O0000 ,urllib as O0OO0OOOOO0000000 #line:3
import re as O0O00OOOO0OOO00OO #line:4
import extract as OOOO000O0O0OO0000 #line:5
import downloader as OOO00OO000O000O0O #line:6
import time as OO00O0OOO000O000O #line:7
import plugintools as O0000O00OOO0O0000 #line:8
from addon .common .addon import Addon as OO0000000OOO0O0O0 #line:9
from addon .common .net import Net as OO0OOOOO0O0O0O000 #line:10
import CheckPath as O0OOOO00OO0000OO0 #line:11
import zipfile as O0O000O0OO00000OO #line:12
import ntpath as O0OO0OOOOO0O00000 #line:13
USER_AGENT ='Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'#line:14
addon_id ='plugin.program.dailyupdateswiz'#line:15
ADDON =OO00OO0OO00O00000 .Addon (id =addon_id )#line:16
AddonID ='plugin.program.dailyupdateswiz'#line:17
AddonTitle ="[COLOR red][B]Daily[/B][/COLOR] [COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Wizard[/COLOR]"#line:18
dialog =O00O00OO0O0O0OO00 .Dialog ()#line:19
net =OO0OOOOO0O0O0O000 ()#line:20
HOME =O0OO0OOOOO000O00O .translatePath ('special://home/')#line:21
dp =O00O00OO0O0O0OO00 .DialogProgress ()#line:22
U =ADDON .getSetting ('User')#line:23
FANART =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('special://home/addons/'+addon_id ,'fanart.jpg'))#line:24
ICON =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('special://home/addons/'+addon_id ,'icon.png'))#line:25
ART =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('special://home/addons/'+addon_id +'/resources/art/'))#line:26
VERSION ="4.0.0"#line:27
DBPATH =O0OO0OOOOO000O00O .translatePath ('special://database')#line:28
TNPATH =O0OO0OOOOO000O00O .translatePath ('special://thumbnails');#line:29
PATH ="Daily Updates Wizard"#line:30
BASEURL ="http://infa.ml/1o"#line:31
H ='http://'#line:32
skin =O0OO0OOOOO000O00O .getSkinDir ()#line:33
EXCLUDES =['plugin.program.dailyupdateswiz','script.module.addon.common']#line:34
zip =ADDON .getSetting ('zip')#line:35
ARTPATH =''+O000OO00O00OOOO00 .sep #line:36
USERDATA =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('special://home/userdata',''))#line:37
MEDIA =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('special://home/media',''))#line:38
AUTOEXEC =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USERDATA ,'autoexec.py'))#line:39
AUTOEXECBAK =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USERDATA ,'autoexec_bak.py'))#line:40
ADDON_DATA =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USERDATA ,'addon_data'))#line:41
PLAYLISTS =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USERDATA ,'playlists'))#line:42
DATABASE =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USERDATA ,'Database'))#line:43
ADDONS =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('special://home','addons',''))#line:44
CBADDONPATH =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (ADDONS ,AddonID ,'default.py'))#line:45
GUISETTINGS =O000OO00O00OOOO00 .path .join (USERDATA ,'guisettings.xml')#line:46
GUI =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USERDATA ,'guisettings.xml'))#line:47
GUIFIX =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USERDATA ,'guifix.xml'))#line:48
INSTALL =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USERDATA ,'install.xml'))#line:49
FAVS =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USERDATA ,'favourites.xml'))#line:50
SOURCE =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USERDATA ,'sources.xml'))#line:51
ADVANCED =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USERDATA ,'advancedsettings.xml'))#line:52
PROFILES =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USERDATA ,'profiles.xml'))#line:53
RSS =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USERDATA ,'RssFeeds.xml'))#line:54
KEYMAPS =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USERDATA ,'keymaps','keyboard.xml'))#line:55
USB =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (zip ))#line:56
CBPATH =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USB ,'Daily Updates Custom Builds',''))#line:57
cookiepath =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (ADDON_DATA ,AddonID ,'cookiejar'))#line:58
startuppath =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (ADDON_DATA ,AddonID ,'startup.xml'))#line:59
tempfile =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (ADDON_DATA ,AddonID ,'temp.xml'))#line:60
idfile =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (ADDON_DATA ,AddonID ,'id.xml'))#line:61
idfiletemp =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (ADDON_DATA ,AddonID ,'idtemp.xml'))#line:62
notifyart =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (ADDONS ,AddonID ,'resources/'))#line:63
skin =O0OO0OOOOO000O00O .getSkinDir ()#line:64
userdatafolder =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (ADDON_DATA ,AddonID ))#line:65
GUINEW =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (userdatafolder ,'guinew.xml'))#line:66
guitemp =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (userdatafolder ,'guitemp',''))#line:67
tempdbpath =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USB ,'Database'))#line:68
urlbase ='None'#line:69
mastercopy =ADDON .getSetting ('mastercopy')#line:70
def INDEX ():#line:71
	addDir ('[COLOR red][B]Daily[/B][/COLOR] [COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Build[/COLOR]',BASEURL ,20 ,ART +'dailywizard.png',FANART ,'')#line:72
	addDir ('[COLOR red][B]Daily[/B][/COLOR] [COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Community[/COLOR]',BASEURL ,21 ,ART +'community.png',FANART ,'')#line:73
	addDir ('[COLOR lime][B]APK[/B] STORE[/COLOR]',BASEURL ,40 ,ART +'apkstore.png',FANART ,'')#line:74
	addDir ('[COLOR yellow]MAINTENANCE[/COLOR]',BASEURL ,30 ,ART +'maintenance.png',FANART ,'')#line:75
	addDir ('[COLOR red]Custom Build Tool[/COLOR]',BASEURL ,50 ,ART +'cbtools.png',FANART ,'')#line:76
	addDir ('[COLOR blue]FACEBOOK[/COLOR]',BASEURL ,8 ,ART +'facebook.jpg',FANART ,'')#line:77
def BUILDMENU ():#line:78
    OO0O0O0O00OO0OO0O =OPEN_URL ('http://infa.ml/mainwiz').replace ('\n','').replace ('\r','')#line:79
    OO00000OO0OOO0000 =O0O00OOOO0OOO00OO .compile ('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0O0O0O00OO0OO0O )#line:80
    for O0O0OOO0O00000O00 ,O0O0OO0000O0O00OO ,O00O000O00OOO0OO0 ,OOOO0000OO0O0O0OO ,O00OOO0000OO000OO in OO00000OO0OOO0000 :#line:81
        addDir (O0O0OOO0O00000O00 ,O0O0OO0000O0O00OO ,90 ,O00O000O00OOO0OO0 ,OOOO0000OO0O0O0OO ,O00OOO0000OO000OO )#line:82
    setView ('movies','MAIN')#line:83
def BUILDMENU2 ():#line:84
    O0000OO0O000OOO00 =OPEN_URL ('http://infa.ml/comwizard').replace ('\n','').replace ('\r','')#line:85
    OOOOOO0OOOOO0O0O0 =O0O00OOOO0OOO00OO .compile ('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0000OO0O000OOO00 )#line:86
    for OO000OO00OO0000O0 ,OOO0O0O0O00O0OOOO ,OO0OO0OOO00OO0OO0 ,O0OO00O0OO0O0O000 ,O0O0OOOO0O000O00O in OOOOOO0OOOOO0O0O0 :#line:87
        addDir (OO000OO00OO0000O0 ,OOO0O0O0O00O0OOOO ,90 ,OO0OO0OOO00OO0OO0 ,O0OO00O0OO0O0O000 ,O0O0OOOO0O000O00O )#line:88
    setView ('movies','MAIN')#line:89
def MAINTENANCE ():#line:90
	addDir ('DELETE CACHE','url',4 ,ART +'deletecache.png',FANART ,'')#line:91
	addDir ('IVUE TV GUIDE RESET','url',11 ,ART +'ivuefix.png',FANART ,'')#line:92
	addDir ('[COLOR red][B]FRESH START[/B][/COLOR]','url',6 ,ART +'freshstart.png',FANART ,'')#line:93
	addDir ('DELETE PACKAGES','url',7 ,ART +'deletepackages.png',FANART ,'')#line:94
	addDir ('CHECK MY IP','url',31 ,ART +'checkmyip.png',FANART ,'')#line:95
	addDir ('FORCE REFRESH','url',32 ,ART +'forcerefresh.png',FANART ,'Force Refresh All Repos')#line:96
	addDir ('DELETE THUBMNAILS','url',33 ,ART +'deletethumbnails.png',FANART ,'Only Works On Android On Windows It Deletes Your Thumnails Folder But Does Not Delete The Textures13.db')#line:97
	setView ('movies','MAIN')#line:98
def CBTOOLS (O000O0O00OO00O0OO ):#line:99
    addDir ('Addon Settings','settings',51 ,ART +'addonsettings.png',FANART ,'')#line:100
    addDir ('Backup My Content','url',60 ,ART +'backupmycontent.png',FANART ,'')#line:101
    addDir ('Restore My Content','url',70 ,ART +'restoremycontent.png',FANART ,'')#line:102
    addDir ('Additional Tools','url',80 ,ART +'additionaltools.png',FANART ,'')#line:103
def APKDOWNMENU ():#line:104
    OO00000OO0OOOO000 =OPEN_URL ('http://infa.ml/appdownload').replace ('\n','').replace ('\r','')#line:105
    OO0OOOO0000O00OOO =O0O00OOOO0OOO00OO .compile ('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO00000OO0OOOO000 )#line:106
    for OOO00O0OO00O00O00 ,O0000OOOOOO00O00O ,OOOOO0OO00OO00O00 ,O0OOO0OOOOO00OO0O ,O0O0O000OO0OOOO0O in OO0OOOO0000O00OOO :#line:107
        addDir (OOO00O0OO00O00O00 ,O0000OOOOOO00O00O ,41 ,OOOOO0OO00OO00O00 ,O0OOO0OOOOO00OO0O ,O0O0O000OO0OOOO0O )#line:108
    setView ('movies','MAIN')#line:109
def APKDOWNWIZ (OOO0O0000O000O0O0 ,O0OOOOO000OOO00OO ,OOO0OO0O0O00O0000 ):#line:110
    OOO00O0OOO000OO0O =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('special://home/addons','packages'))#line:111
    OOOOOOOO0000000O0 =O00O00OO0O0O0OO00 .DialogProgress ()#line:112
    OOOOOOOO0000000O0 .create ("Daily Updates APKS","Downloading your app ",'','Please Wait')#line:113
    O000OOO0OO0OOO0O0 =O000OO00O00OOOO00 .path .join (OOO00O0OOO000OO0O ,OOO0O0000O000O0O0 +'.zip')#line:114
    try :#line:115
       O000OO00O00OOOO00 .remove (O000OOO0OO0OOO0O0 )#line:116
    except :#line:117
       pass #line:118
    OOO00OO000O000O0O .download (O0OOOOO000OOO00OO ,O000OOO0OO0OOO0O0 ,OOOOOOOO0000000O0 )#line:119
    O0OO00OOOO0O000O0 =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('sdcard','download'))#line:120
    OO00O0OOO000O000O .sleep (2 )#line:121
    OOOOOOOO0000000O0 .update (0 ,"","transfering your app to the downloads folder on your device")#line:122
    print ('=======================================')#line:123
    print (O0OO00OOOO0O000O0 )#line:124
    print ('=======================================')#line:125
    OOOO000O0O0OO0000 .all (O000OOO0OO0OOO0O0 ,O0OO00OOOO0O000O0 ,OOOOOOOO0000000O0 )#line:126
    OO000OOOO000O0OOO =O00O00OO0O0O0OO00 .Dialog ()#line:127
    OO000OOOO000O0OOO .ok ("DOWNLOAD COMPLETE ","PLEASE EXIT KODI AND GO TO YOUR DOWNLOADS FOLDER AND INSTALL YOUR APP")#line:128
def TextBoxes (OO0O0OO0O0O0O000O ,O0OOOOO00OOO0000O ):#line:129
  class O0O0OOOOO00000OOO ():#line:130
    WINDOW =10147 #line:131
    CONTROL_LABEL =1 #line:132
    CONTROL_TEXTBOX =5 #line:133
    def __init__ (O0O00OOOO0O00OO00 ,*O000000OO0O0OO0OO ,**O0000OO0OO00OOOO0 ):#line:134
      O0OO0OOOOO000O00O .executebuiltin ("ActivateWindow(%d)"%(O0O00OOOO0O00OO00 .WINDOW ,))#line:135
      O0O00OOOO0O00OO00 .win =O00O00OO0O0O0OO00 .Window (O0O00OOOO0O00OO00 .WINDOW )#line:136
      O0OO0OOOOO000O00O .sleep (500 )#line:137
      O0O00OOOO0O00OO00 .setControls ()#line:138
    def setControls (OOOOO0000O00O00OO ):#line:139
      OOOOO0000O00O00OO .win .getControl (OOOOO0000O00O00OO .CONTROL_LABEL ).setLabel (OO0O0OO0O0O0O000O )#line:140
      try :OO0OO00OO00OOO0OO =open (O0OOOOO00OOO0000O );O0OOOO000000OO0OO =OO0OO00OO00OOO0OO .read ()#line:141
      except :O0OOOO000000OO0OO =O0OOOOO00OOO0000O #line:142
      OOOOO0000O00O00OO .win .getControl (OOOOO0000O00O00OO .CONTROL_TEXTBOX ).setText (str (O0OOOO000000OO0OO ))#line:143
      return #line:144
  O0O0OOOOO00000OOO ()#line:145
def facebook ():#line:146
    TextBoxes ('[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Team[/COLOR]','Join the discussions at [COLOR blue]http://infa.ml/1o[/COLOR]')#line:147
def Notify (O000OO0O00OO00O00 ,O0O0OOOOOOOOO0O0O ,OO0000O0000O0OO0O ,OOOOOOOO000OOOOOO ):#line:148
    OOOOOOOO000OOOOOO =notifyart +OOOOOOOO000OOOOOO #line:149
    O0OO0OOOOO000O00O .executebuiltin ("XBMC.Notification("+O000OO0O00OO00O00 +","+O0O0OOOOOOOOO0O0O +","+OO0000O0000O0OO0O +","+OOOOOOOO000OOOOOO +")")#line:150
class SPLASH (O00O00OO0O0O0OO00 .WindowXMLDialog ):#line:151
    def __init__ (OOOOOO00OO0O0O00O ,*OO00OO000OOO0OO0O ,**O00O000OOOO00O00O ):OOOOOO00OO0O0O00O .shut =O00O000OOOO00O00O ['close_time'];O0OO0OOOOO000O00O .executebuiltin ("Skin.Reset(AnimeWindowXMLDialogClose)");O0OO0OOOOO000O00O .executebuiltin ("Skin.SetBool(AnimeWindowXMLDialogClose)")#line:152
    def onFocus (OO0OO0OOOO00O0OOO ,O0O00OO00OO0O0OO0 ):pass #line:153
    def onClick (OO00O0O0OO0O00O0O ,OO00OO0O0OOOO000O ):#line:154
        if OO00OO0O0OOOO000O ==90 :O0OO0OOOOO000O00O .Player ().stop ();OO00O0O0OO0O00O0O ._close_dialog ()#line:155
    def onAction (OO00OO0OOOOO0O000 ,O0OO00O00O00OO0OO ):#line:156
        if O0OO00O00O00OO0OO in [5 ,6 ,7 ,9 ,10 ,92 ,117 ]or O0OO00O00O00OO0OO .getButtonCode ()in [275 ,257 ,261 ]:O0OO0OOOOO000O00O .Player ().stop ();OO00OO0OOOOO0O000 ._close_dialog ()#line:157
    def _close_dialog (O0OOOO000OO00OO0O ):#line:158
        O0OO0OOOOO000O00O .executebuiltin ("Skin.Reset(AnimeWindowXMLDialogClose)");OO00O0OOO000O000O .sleep (.4 );O0OOOO000OO00OO0O .close ()#line:159
def pop ():#line:160
    OO0OOO000O00OOOO0 =SPLASH ('dailyupdates.xml',ADDON .getAddonInfo ('path'),'DefaultSkin',close_time =34 )#line:161
    OO0OOO000O00OOOO0 .doModal ()#line:162
    del OO0OOO000O00OOOO0 #line:163
def VideoCheck ():#line:164
    import yt as OO0000OO00OO00OOO #line:165
    OO0O0OOO0O0O0000O ='no'#line:166
    if not O000OO00O00OOOO00 .path .exists (userdatafolder ):#line:167
        O000OO00O00OOOO00 .makedirs (userdatafolder )#line:168
    if not O000OO00O00OOOO00 .path .exists (startuppath ):#line:169
        OO000O0O00O00OO0O =open (startuppath ,mode ='w+')#line:170
        OO000O0O00O00OO0O .write ('date="01011001"\nversion="0.0"')#line:171
        OO000O0O00O00OO0O .close ()#line:172
    if not O000OO00O00OOOO00 .path .exists (idfile ):#line:173
        OO000O0O00O00OO0O =open (idfile ,mode ='w+')#line:174
        OO000O0O00O00OO0O .write ('id="None"\nname="None"')#line:175
        OO000O0O00O00OO0O .close ()#line:176
    else :#line:177
        pop ()#line:178
    INDEX ()#line:179
def COMMUNITY_BACKUP ():#line:180
    OOO0O00O00OO00000 =1 #line:181
    CHECK_DOWNLOAD_PATH ()#line:182
    O0O00O0O000OO00O0 =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USB ,'Daily Updates','My Builds',''))#line:183
    O0OO0OO0O0O000000 =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USB ,'Daily Updates','My Builds','my_full_backup.zip'))#line:184
    OOO00000O00O00OOO =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USB ,'Daily Updates','My Builds','my_full_backup_GUI_Settings.zip'))#line:185
    if not O000OO00O00OOOO00 .path .exists (O0O00O0O000OO00O0 ):#line:186
        O000OO00O00OOOO00 .makedirs (O0O00O0O000OO00O0 )#line:187
    O000O0OO0OOO0O0OO =_O0OO00OOO0000OOOO (heading ="Enter a name for this backup")#line:188
    if (not O000O0OO0OOO0O0OO ):return False ,0 #line:189
    OOO00OOOO0000OOO0 =O0OO0OOOOO0000000 .quote_plus (O000O0OO0OOO0O0OO )#line:190
    O00O0OOO0OOO0O000 =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (O0O00O0O000OO00O0 ,OOO00OOOO0000OOO0 +'.zip'))#line:191
    OO000O00O0O000O0O =['plugin.program.dailyupdateswiz']#line:192
    OOO0OOOO0O0OOOO00 =["xbmc.log","xbmc.old.log","kodi.log","kodi.old.log",'.DS_Store','.setup_complete','XBMCHelper.conf']#line:193
    OOO0O0O0000OO0O0O =['plugin.program.dailyupdateswiz','cache','system','Thumbnails',"peripheral_data",'library','keymaps']#line:194
    OO0O0O000OOOO0O0O =["xbmc.log","xbmc.old.log","kodi.log","kodi.old.log","Textures13.db",'.DS_Store','.setup_complete','XBMCHelper.conf','advancedsettings.xml']#line:195
    OOO0OO0O00O0OOO00 ="Creating full backup of existing build"#line:196
    OO0OO0000OO00000O ="Creating Daily Updates Custom Build"#line:197
    O000000OOOO0OOO0O ="Archiving..."#line:198
    O0O0OO00OO000OOOO =""#line:199
    O00OO000OOOO0O00O ="Please Wait"#line:200
    if mastercopy =='true':#line:201
        ARCHIVE_CB (HOME ,O0OO0OO0O0O000000 ,OOO0OO0O00O0OOO00 ,O000000OOOO0OOO0O ,O0O0OO00OO000OOOO ,O00OO000OOOO0O00O ,OO000O00O0O000O0O ,OOO0OOOO0O0OOOO00 )#line:202
    OO000O0O00OO00O00 =O00O00OO0O0O0OO00 .Dialog ().yesno ("Do you want to include your addon_data folder?",'This contains ALL addon settings including passwords.','If you\'re intending on sharing this with others we strongly','recommend against this unless all data has been manually removed.',yeslabel ='Yes',nolabel ='No')#line:203
    if OO000O0O00OO00O00 ==0 :#line:204
        DeletePackages2 ()#line:205
    elif OO000O0O00OO00O00 ==1 :#line:206
        pass #line:207
    FIX_SPECIAL (HOME )#line:208
    ARCHIVE_CB (HOME ,O00O0OOO0OOO0O000 ,OO0OO0000OO00000O ,O000000OOOO0OOO0O ,O0O0OO00OO000OOOO ,O00OO000OOOO0O00O ,OOO0O0O0000OO0O0O ,OO0O0O000OOOO0O0O )#line:209
    OO00O0OOO000O000O .sleep (1 )#line:210
    O00OO00OO0O00OO0O =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (O0O00O0O000OO00O0 ,OOO00OOOO0000OOO0 +'_guisettings.zip'))#line:211
    OOOO000OOOOOO0OOO =O0O000O0OO00000OO .ZipFile (O00OO00OO0O00OO0O ,mode ='w')#line:212
    try :#line:213
        OOOO000OOOOOO0OOO .write (GUI ,'guisettings.xml',O0O000O0OO00000OO .ZIP_DEFLATED )#line:214
    except :OOO0O00O00OO00000 =0 #line:215
    try :#line:216
        OOOO000OOOOOO0OOO .write (O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (HOME ,'userdata','profiles.xml')),'profiles.xml',O0O000O0OO00000OO .ZIP_DEFLATED )#line:217
    except :pass #line:218
    OOOO000OOOOOO0OOO .close ()#line:219
    if mastercopy =='true':#line:220
        OOOOOO00000O0000O =O0O000O0OO00000OO .ZipFile (OOO00000O00O00OOO ,mode ='w')#line:221
        try :#line:222
            OOOOOO00000O0000O .write (GUI ,'guisettings.xml',O0O000O0OO00000OO .ZIP_DEFLATED )#line:223
        except :OOO0O00O00OO00000 =0 #line:224
        try :#line:225
            OOOOOO00000O0000O .write (O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (HOME ,'userdata','profiles.xml')),'profiles.xml',O0O000O0OO00000OO .ZIP_DEFLATED )#line:226
        except :pass #line:227
        OOOOOO00000O0000O .close ()#line:228
    if OOO0O00O00OO00000 ==0 :#line:229
        dialog .ok ("[COLOR red][B]FAILED![/B][/COLOR]",'The guisettings.xml file could not be found on your','system, please reboot and try again.','')#line:230
    else :#line:231
        dialog .ok ("[COLOR green][B]SUCCESS![/B][/COLOR]",'You Are Now Backed Up.')#line:232
        dialog .ok ("Build Locations",'Full Backup (only used to restore on this device): [COLOR=yellow]'+O0OO0OO0O0O000000 ,'[/COLOR]Universal Backup (can be used on any device): [COLOR=yellow]'+O00O0OOO0OOO0O000 +'[/COLOR]')#line:233
def ARCHIVE_SINGLE (OO000OO0O00OO0000 ,O000OOO0O000O00O0 ,O0O000OOOO00OO0OO ):#line:234
    O00O000OO0OO0O000 =O0O000O0OO00000OO .ZipFile (O000OOO0O000O00O0 ,mode ='w')#line:235
    O00O000OO0OO0O000 .write (OO000OO0O00OO0000 ,O0O000OOOO00OO0OO ,O0O000O0OO00000OO .ZIP_DEFLATED )#line:236
    O00O000OO0OO0O000 .close ()#line:237
def FIX_SPECIAL (O00OO0O0O0O0O000O ):#line:238
    dp .create ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Team[/COLOR] Builds","Renaming paths...",'','Please Wait')#line:239
    for OOOOOOOO0OOOO0O00 ,OO0OOO00000OO0OO0 ,OOO0O0O0O0O00OOO0 in O000OO00O00OOOO00 .walk (O00OO0O0O0O0O000O ):#line:240
        for O00OO0O0O0OOO000O in OOO0O0O0O0O00OOO0 :#line:241
            if O00OO0O0O0OOO000O .endswith (".xml"):#line:242
                 dp .update (0 ,"Fixing",O00OO0O0O0OOO000O ,'Please Wait')#line:243
                 OOOOOO00OO00O0OOO =open ((O000OO00O00OOOO00 .path .join (OOOOOOOO0OOOO0O00 ,O00OO0O0O0OOO000O ))).read ()#line:244
                 OOO00OO0000O0O00O =OOOOOO00OO00O0OOO .replace (USERDATA ,'special://profile/').replace (ADDONS ,'special://home/addons/')#line:245
                 OO0O000OO0O0OO0O0 =open ((O000OO00O00OOOO00 .path .join (OOOOOOOO0OOOO0O00 ,O00OO0O0O0OOO000O )),mode ='w')#line:246
                 OO0O000OO0O0OO0O0 .write (str (OOO00OO0000O0O00O ))#line:247
                 OO0O000OO0O0OO0O0 .close ()#line:248
def ARCHIVE_FILE (O0OOO00000000OO00 ,O0000OO0OO00O00O0 ):#line:249
    O0OO00OOOO0O0O000 =O0O000O0OO00000OO .ZipFile (O0000OO0OO00O00O0 ,'w',O0O000O0OO00000OO .ZIP_DEFLATED )#line:250
    O0OO0O000O0OO00OO =len (O0OOO00000000OO00 )#line:251
    O0O0O00OO0O0OOO00 =[]#line:252
    O00OOO00O0O0O00OO =[]#line:253
    dp .create ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds","Archiving...",'','Please Wait')#line:254
    for O00OOO0000OOO0000 ,OOOOO00OO0OOOO000 ,OO0OOOOOO000O0O0O in O000OO00O00OOOO00 .walk (O0OOO00000000OO00 ):#line:255
        for O0O0O0OO0O0OO0OOO in OO0OOOOOO000O0O0O :#line:256
            O00OOO00O0O0O00OO .append (O0O0O0OO0O0OO0OOO )#line:257
    O0000OO0OOOO00OOO =len (O00OOO00O0O0O00OO )#line:258
    for O00OOO0000OOO0000 ,OOOOO00OO0OOOO000 ,OO0OOOOOO000O0O0O in O000OO00O00OOOO00 .walk (O0OOO00000000OO00 ):#line:259
        for O0O0O0OO0O0OO0OOO in OO0OOOOOO000O0O0O :#line:260
            O0O0O00OO0O0OOO00 .append (O0O0O0OO0O0OO0OOO )#line:261
            OO0O000O0O0O0OO0O =len (O0O0O00OO0O0OOO00 )/float (O0000OO0OOOO00OOO )*100 #line:262
            dp .update (int (OO0O000O0O0O0OO0O ),"Backing Up",'[COLOR yellow]%s[/COLOR]'%O0O0O0OO0O0OO0OOO ,'Please Wait')#line:263
            O0OO00O0OO0OOO0OO =O000OO00O00OOOO00 .path .join (O00OOO0000OOO0000 ,O0O0O0OO0O0OO0OOO )#line:264
            if not 'temp'in OOOOO00OO0OOOO000 :#line:265
                if not 'plugin.program.dailyupdateswiz'in OOOOO00OO0OOOO000 :#line:266
                   import time as OO0O0O0OOO0OOOOO0 #line:267
                   O00O0O0O00000O0O0 ='01/01/1980'#line:268
                   O0O00OOOOOO0O0O0O =OO0O0O0OOO0OOOOO0 .strftime ('%d/%m/%Y',OO0O0O0OOO0OOOOO0 .gmtime (O000OO00O00OOOO00 .path .getmtime (O0OO00O0OO0OOO0OO )))#line:269
                   if O0O00OOOOOO0O0O0O >O00O0O0O00000O0O0 :#line:270
                       O0OO00OOOO0O0O000 .write (O0OO00O0OO0OOO0OO ,O0OO00O0OO0OOO0OO [O0OO0O000O0OO00OO :])#line:271
    O0OO00OOOO0O0O000 .close ()#line:272
    dp .close ()#line:273
def ARCHIVE_CB (O0O0O000OOO0O0OO0 ,OOOO00O0OOO00O0OO ,OO00O0OOO0OO00OO0 ,O0O000OOOO00O0OOO ,O00O00OOOO0OO0O00 ,O0O0000OO000OO0O0 ,OOO000OO0OO0O0O0O ,OO00O00OO0000O00O ):#line:274
    OO00OOOO0OO00OOOO =O0O000O0OO00000OO .ZipFile (OOOO00O0OOO00O0OO ,'w',O0O000O0OO00000OO .ZIP_DEFLATED )#line:275
    OO0O0000OO00OOO0O =len (O0O0O000OOO0O0OO0 )#line:276
    O0OO0O00O00OOOO00 =[]#line:277
    OO00OOO00O00O0000 =[]#line:278
    dp .create (OO00O0OOO0OO00OO0 ,O0O000OOOO00O0OOO ,O00O00OOOO0OO0O00 ,O0O0000OO000OO0O0 )#line:279
    for OO000OO00OO000OO0 ,OOO0OO000O0000O00 ,O0OOO000OO0O0O0O0 in O000OO00O00OOOO00 .walk (O0O0O000OOO0O0OO0 ):#line:280
        for O0OOOO000O0000000 in O0OOO000OO0O0O0O0 :#line:281
            OO00OOO00O00O0000 .append (O0OOOO000O0000000 )#line:282
    O0OO000O000O0000O =len (OO00OOO00O00O0000 )#line:283
    for OO000OO00OO000OO0 ,OOO0OO000O0000O00 ,O0OOO000OO0O0O0O0 in O000OO00O00OOOO00 .walk (O0O0O000OOO0O0OO0 ):#line:284
        OOO0OO000O0000O00 [:]=[O00O00000OOOOOO00 for O00O00000OOOOOO00 in OOO0OO000O0000O00 if O00O00000OOOOOO00 not in OOO000OO0OO0O0O0O ]#line:285
        O0OOO000OO0O0O0O0 [:]=[O00OO0OO00O0000OO for O00OO0OO00O0000OO in O0OOO000OO0O0O0O0 if O00OO0OO00O0000OO not in OO00O00OO0000O00O ]#line:286
        for O0OOOO000O0000000 in O0OOO000OO0O0O0O0 :#line:287
            O0OO0O00O00OOOO00 .append (O0OOOO000O0000000 )#line:288
            OOOO0O0O000OOOOOO =len (O0OO0O00O00OOOO00 )/float (O0OO000O000O0000O )*100 #line:289
            dp .update (int (OOOO0O0O000OOOOOO ),"Backing Up",'[COLOR yellow]%s[/COLOR]'%O0OOOO000O0000000 ,'Please Wait')#line:290
            O000O000000000O0O =O000OO00O00OOOO00 .path .join (OO000OO00OO000OO0 ,O0OOOO000O0000000 )#line:291
            if not 'temp'in OOO0OO000O0000O00 :#line:292
                if not 'plugin.program.dailyupdateswiz'in OOO0OO000O0000O00 :#line:293
                   import time as O000OO00OOOO00O00 #line:294
                   O00O00OOO000O00OO ='01/01/1980'#line:295
                   OO00O0O0OO0OOO000 =O000OO00OOOO00O00 .strftime ('%d/%m/%Y',O000OO00OOOO00O00 .gmtime (O000OO00O00OOOO00 .path .getmtime (O000O000000000O0O )))#line:296
                   if OO00O0O0OO0OOO000 >O00O00OOO000O00OO :#line:297
                       OO00OOOO0OO00OOOO .write (O000O000000000O0O ,O000O000000000O0O [OO0O0000OO00OOO0O :])#line:298
    OO00OOOO0OO00OOOO .close ()#line:299
    dp .close ()#line:300
def READ_ZIP (OOO00O00OO0O000OO ):#line:301
    import zipfile as OO0O0O0O00OO0OOOO #line:302
    OO0O0000OO0OO0O00 =OO0O0O0O00OO0OOOO .ZipFile (OOO00O00OO0O000OO ,"r")#line:303
    for O0OOOOOO0O0OO0000 in OO0O0000OO0OO0O00 .namelist ():#line:304
        if 'guisettings.xml'in O0OOOOOO0O0OO0000 :#line:305
            OO0OO0OO0OOO000OO =OO0O0000OO0OO0O00 .read (O0OOOOOO0O0OO0000 )#line:306
            OOO00OOO0O0000OOO ='<setting type="(.+?)" name="%s.(.+?)">(.+?)</setting>'%skin #line:307
            O0O00OO0O00O0OOO0 =O0O00OOOO0OOO00OO .compile (OOO00OOO0O0000OOO ).findall (OO0OO0OO0OOO000OO )#line:308
            for O0OOO000O00O0000O ,OOOO000O0OO0OO00O ,OOOOO000O0O0OOOO0 in O0O00OO0O00O0OOO0 :#line:309
                OOOOO000O0O0OOOO0 =OOOOO000O0O0OOOO0 .replace ('&quot;','').replace ('&amp;','&')#line:310
                O0OO0OOOOO000O00O .executebuiltin ("Skin.Set%s(%s,%s)"%(O0OOO000O00O0000O .title (),OOOO000O0OO0OO00O ,OOOOO000O0O0OOOO0 ))#line:311
        if 'favourites.xml'in O0OOOOOO0O0OO0000 :#line:312
            OO0OO0OO0OOO000OO =OO0O0000OO0OO0O00 .read (O0OOOOOO0O0OO0000 )#line:313
            O000OOOO0O0O000OO =open (FAVS ,mode ='w')#line:314
            O000OOOO0O0O000OO .write (OO0OO0OO0OOO000OO )#line:315
            O000OOOO0O0O000OO .close ()#line:316
        if 'sources.xml'in O0OOOOOO0O0OO0000 :#line:317
            OO0OO0OO0OOO000OO =OO0O0000OO0OO0O00 .read (O0OOOOOO0O0OO0000 )#line:318
            O000OOOO0O0O000OO =open (SOURCE ,mode ='w')#line:319
            O000OOOO0O0O000OO .write (OO0OO0OO0OOO000OO )#line:320
            O000OOOO0O0O000OO .close ()#line:321
        if 'advancedsettings.xml'in O0OOOOOO0O0OO0000 :#line:322
            OO0OO0OO0OOO000OO =OO0O0000OO0OO0O00 .read (O0OOOOOO0O0OO0000 )#line:323
            O000OOOO0O0O000OO =open (ADVANCED ,mode ='w')#line:324
            O000OOOO0O0O000OO .write (OO0OO0OO0OOO000OO )#line:325
            O000OOOO0O0O000OO .close ()#line:326
        if 'RssFeeds.xml'in O0OOOOOO0O0OO0000 :#line:327
            OO0OO0OO0OOO000OO =OO0O0000OO0OO0O00 .read (O0OOOOOO0O0OO0000 )#line:328
            O000OOOO0O0O000OO =open (RSS ,mode ='w')#line:329
            O000OOOO0O0O000OO .write (OO0OO0OO0OOO000OO )#line:330
            O000OOOO0O0O000OO .close ()#line:331
        if 'keyboard.xml'in O0OOOOOO0O0OO0000 :#line:332
            OO0OO0OO0OOO000OO =OO0O0000OO0OO0O00 .read (O0OOOOOO0O0OO0000 )#line:333
            O000OOOO0O0O000OO =open (KEYMAPS ,mode ='w')#line:334
            O000OOOO0O0O000OO .write (OO0OO0OO0OOO000OO )#line:335
            O000OOOO0O0O000OO .close ()#line:336
def FACTORY (OO0O00OOOO0000O00 ,O0OO000OO0OO0O00O ,OOO000OOOOOOOO000 ,OO0O0000OO0O0OOOO ):#line:337
    pass #line:338
def OPEN_URL (O0OOO00OOOO00OO00 ):#line:339
    OOOO0OO000O00OO0O =OO0OOOOO0000O0000 .Request (O0OOO00OOOO00OO00 )#line:340
    OOOO0OO000O00OO0O .add_header ('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')#line:341
    O0000OOO0O00000O0 =OO0OOOOO0000O0000 .urlopen (OOOO0OO000O00OO0O )#line:342
    O0O0O00O0000O000O =O0000OOO0O00000O0 .read ()#line:343
    O0000OOO0O00000O0 .close ()#line:344
    return O0O0O00O0000O000O #line:345
def RESTORE_COMMUNITY (OO0OOO0OO000O00OO ,O0OOOOO0OOO000000 ,OO00OOOO000OOOO00 ,OO0O0OO0000OOOO0O ,OOOO0000O000O000O ,OO000O00O00OOOO0O ):#line:346
    import time as OOOOOOOOO0OOOO0OO #line:347
    O000O0OO00O000000 =1 #line:348
    CHECK_DOWNLOAD_PATH ()#line:349
    if O000OO00O00OOOO00 .path .exists (GUINEW ):#line:350
        if O000OO00O00OOOO00 .path .exists (GUI ):#line:351
            O000OO00O00OOOO00 .remove (GUINEW )#line:352
        else :#line:353
            O000OO00O00OOOO00 .rename (GUINEW ,GUI )#line:354
    if O000OO00O00OOOO00 .path .exists (GUIFIX ):#line:355
        O000OO00O00OOOO00 .remove (GUIFIX )#line:356
    if not O000OO00O00OOOO00 .path .exists (tempfile ):#line:357
        OOO000000O0OO00OO =open (tempfile ,mode ='w+')#line:358
    if O000OO00O00OOOO00 .path .exists (guitemp ):#line:359
        O000OO00O00OOOO00 .removedirs (guitemp )#line:360
    try :O000OO00O00OOOO00 .rename (GUI ,GUINEW )#line:361
    except :#line:362
        dialog .ok ("NO GUISETTINGS!",'No guisettings.xml file has been found.','Please exit XBMC and try again','')#line:363
        return #line:364
    O000OO0O00O0O0000 =O00O00OO0O0O0OO00 .Dialog ().yesno (OO0OOO0OO000O00OO ,'We highly recommend backing up your existing build before','installing any Daily Updates Builds.','Would you like to perform a backup first?',nolabel ='Backup',yeslabel ='Install')#line:365
    if O000OO0O00O0O0000 ==0 :#line:366
        O0000O0O0O0OOO0O0 =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USB ,'Daily Updates Builds','My Builds'))#line:367
        if not O000OO00O00OOOO00 .path .exists (O0000O0O0O0OOO0O0 ):#line:368
            O000OO00O00OOOO00 .makedirs (O0000O0O0O0OOO0O0 )#line:369
        O00OO000O0OO000OO =_O0OO00OOO0000OOOO (heading ="Enter a name for this backup")#line:370
        if (not O00OO000O0OO000OO ):return False ,0 #line:371
        O00O0O00000O0000O =O0OO0OOOOO0000000 .quote_plus (O00OO000O0OO000OO )#line:372
        OO00OO0O00OOOO000 =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (O0000O0O0O0OOO0O0 ,O00O0O00000O0000O +'.zip'))#line:373
        O0OOOOOO0O0OO0O0O =['plugin.program.dailyupdateswiz']#line:374
        O0O00OOOOO0000OOO =["xbmc.log","xbmc.old.log","kodi.log","kodi.old.log",'.DS_Store','.setup_complete','XBMCHelper.conf']#line:375
        O0OOOOO00OO000OO0 ="Creating full backup of existing build"#line:376
        OOO000OOO0OOOOO0O ="Archiving..."#line:377
        O0O0O0000O00O0000 =""#line:378
        OO0O000OOO0O0O0O0 ="Please Wait"#line:379
        ARCHIVE_CB (HOME ,OO00OO0O00OOOO000 ,O0OOOOO00OO000OO0 ,OOO000OOO0OOOOO0O ,O0O0O0000O00O0000 ,OO0O000OOO0O0O0O0 ,O0OOOOOO0O0OO0O0O ,O0O00OOOOO0000OOO )#line:380
    O0O0OO0O00OO0O0OO =O00O00OO0O0O0OO00 .Dialog ().yesno (OO0OOO0OO000O00OO ,'Would you like to keep your existing database','files or overwrite? Overwriting will wipe any','existing library you may have scanned in.',nolabel ='Overwrite',yeslabel ='Keep Existing')#line:381
    if O0O0OO0O00OO0O0OO ==0 :pass #line:382
    elif O0O0OO0O00OO0O0OO ==1 :#line:383
        if O000OO00O00OOOO00 .path .exists (tempdbpath ):#line:384
            O0O0O0O0O000000O0 .rmtree (tempdbpath )#line:385
        try :#line:386
            O0O0O0O0O000000O0 .copytree (DATABASE ,tempdbpath ,symlinks =False ,ignore =O0O0O0O0O000000O0 .ignore_patterns ("Textures13.db","Addons16.db","Addons15.db","saltscache.db-wal","saltscache.db-shm","saltscache.db","onechannelcache.db"))#line:387
        except :#line:388
            O000O0OO00O000000 =O00O00OO0O0O0OO00 .Dialog ().yesno (OO0OOO0OO000O00OO ,'There was an error trying to backup some databases.','Continuing may wipe your existing library. Do you','wish to continue?',nolabel ='No, cancel',yeslabel ='Yes, overwrite')#line:389
            if O000O0OO00O000000 ==1 :pass #line:390
            if O000O0OO00O000000 ==0 :return #line:391
        OO00OO0O00OOOO000 =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USB ,'Database.zip'))#line:392
        ARCHIVE_FILE (tempdbpath ,OO00OO0O00OOOO000 )#line:393
    if O000O0OO00O000000 ==0 :return #line:394
    OOOOOOOOO0OOOO0OO .sleep (1 )#line:395
    dp .create ("Daily Updates Builds","Downloading "+OO0O0OO0000OOOO0O +" build.",'','Please Wait')#line:396
    O00000O0O0O00OOO0 =O000OO00O00OOOO00 .path .join (CBPATH ,OO0O0OO0000OOOO0O +'.zip')#line:397
    if not O000OO00O00OOOO00 .path .exists (CBPATH ):#line:398
        O000OO00O00OOOO00 .makedirs (CBPATH )#line:399
    OOO00OO000O000O0O .download (O0OOOOO0OOO000000 ,O00000O0O0O00OOO0 ,dp )#line:400
    O0000OO00OOO000OO =open (CBADDONPATH ,mode ='r')#line:401
    OO000OO0000O0000O =O0000OO00OOO000OO .read ()#line:402
    O0000OO00OOO000OO .close ()#line:403
    READ_ZIP (O00000O0O0O00OOO0 )#line:404
    dp .create ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds","Checking ",'','Please Wait')#line:405
    dp .update (0 ,"","Extracting Zip Please Wait")#line:406
    OOOO000O0O0OO0000 .all (O00000O0O0O00OOO0 ,HOME ,dp )#line:407
    OOOOOOOOO0OOOO0OO .sleep (1 )#line:408
    if localcopy =='false':#line:409
        O000OO00O00OOOO00 .remove (O00000O0O0O00OOO0 )#line:410
    O0OOO00O00O0000OO =open (CBADDONPATH ,mode ='w+')#line:411
    O0OOO00O00O0000OO .write (OO000OO0000O0000O )#line:412
    O0OOO00O00O0000OO .close ()#line:413
    try :#line:414
        O000OO00O00OOOO00 .rename (GUI ,GUIFIX )#line:415
    except :#line:416
        print ('NO GUISETTINGS DOWNLOADED')#line:417
    OOOOOOOOO0OOOO0OO .sleep (1 )#line:418
    OOO000000O0OO00OO =open (GUINEW ,mode ='r')#line:419
    O00O0O0OOOOO00OOO =file .read (OOO000000O0OO00OO )#line:420
    file .close (OOO000000O0OO00OO )#line:421
    O00OO00O0OO0O000O =O0O00OOOO0OOO00OO .compile ('<skinsettings>[\s\S]*?<\/skinsettings>').findall (O00O0O0OOOOO00OOO )#line:422
    O000000OO00OOO0OO =O00OO00O0OO0O000O [0 ]if (len (O00OO00O0OO0O000O )>0 )else ''#line:423
    OO00O0O00OO000O0O =O0O00OOOO0OOO00OO .compile ('<skin default[\s\S]*?<\/skin>').findall (O00O0O0OOOOO00OOO )#line:424
    OOOO00OOO0O00O000 =OO00O0O00OO000O0O [0 ]if (len (OO00O0O00OO000O0O )>0 )else ''#line:425
    O00OO0O0O00O0O0OO =O0O00OOOO0OOO00OO .compile ('<lookandfeel>[\s\S]*?<\/lookandfeel>').findall (O00O0O0OOOOO00OOO )#line:426
    OOO00O0O000O000O0 =O00OO0O0O00O0O0OO [0 ]if (len (O00OO0O0O00O0O0OO )>0 )else ''#line:427
    try :#line:428
        OO0O0O00O00OOOOO0 =open (GUIFIX ,mode ='r')#line:429
        OOOOOOO0OOOO0OO00 =file .read (OO0O0O00O00OOOOO0 )#line:430
        file .close (OO0O0O00O00OOOOO0 )#line:431
        OO0O0OOO000000O00 =O0O00OOOO0OOO00OO .compile ('<skinsettings>[\s\S]*?<\/skinsettings>').findall (OOOOOOO0OOOO0OO00 )#line:432
        O000OO0O0O0O000O0 =OO0O0OOO000000O00 [0 ]if (len (OO0O0OOO000000O00 )>0 )else ''#line:433
        OO000OO0O0O000OO0 =O0O00OOOO0OOO00OO .compile ('<skin default[\s\S]*?<\/skin>').findall (OOOOOOO0OOOO0OO00 )#line:434
        O0O0OO00O0OOOO000 =OO000OO0O0O000OO0 [0 ]if (len (OO000OO0O0O000OO0 )>0 )else ''#line:435
        OOO0OOO0O0000OOO0 =O0O00OOOO0OOO00OO .compile ('<lookandfeel>[\s\S]*?<\/lookandfeel>').findall (OOOOOOO0OOOO0OO00 )#line:436
        OO00OOOOO00O0OO00 =OOO0OOO0O0000OOO0 [0 ]if (len (OOO0OOO0O0000OOO0 )>0 )else ''#line:437
        O00000OOO0OOOO0O0 =O00O0O0OOOOO00OOO .replace (O000000OO00OOO0OO ,O000OO0O0O0O000O0 ).replace (OOO00O0O000O000O0 ,OO00OOOOO00O0OO00 ).replace (OOOO00OOO0O00O000 ,O0O0OO00O0OOOO000 )#line:438
        O00OO00OOO00O0000 =open (GUINEW ,mode ='w+')#line:439
        O00OO00OOO00O0000 .write (str (O00000OOO0OOOO0O0 ))#line:440
        O00OO00OOO00O0000 .close ()#line:441
    except :#line:442
        print ('NO GUISETTINGS DOWNLOADED')#line:443
    if O000OO00O00OOOO00 .path .exists (GUI ):#line:444
        O000OO00O00OOOO00 .remove (GUI )#line:445
    O000OO00O00OOOO00 .rename (GUINEW ,GUI )#line:446
    try :#line:447
        O000OO00O00OOOO00 .remove (GUIFIX )#line:448
    except :#line:449
        pass #line:450
    if O0O0OO0O00OO0O0OO ==1 :#line:451
        OOOO000O0O0OO0000 .all (OO00OO0O00OOOO000 ,DATABASE ,dp )#line:452
        if O000O0OO00O000000 !=1 :#line:453
            O0O0O0O0O000000O0 .rmtree (tempdbpath )#line:454
    dp .close ()#line:455
    O000OO00O00OOOO00 .makedirs (guitemp )#line:456
    OOOOOOOOO0OOOO0OO .sleep (1 )#line:457
    O0OO0OOOOO000O00O .executebuiltin ('UnloadSkin()')#line:458
    OOOOOOOOO0OOOO0OO .sleep (1 )#line:459
    O0OO0OOOOO000O00O .executebuiltin ('ReloadSkin()')#line:460
    OOOOOOOOO0OOOO0OO .sleep (1 )#line:461
    O0OO0OOOOO000O00O .executebuiltin ("ActivateWindow(appearancesettings)")#line:462
    while O0OO0OOOOO000O00O .executebuiltin ("Window.IsActive(appearancesettings)"):#line:463
        O0OO0OOOOO000O00O .sleep (500 )#line:464
    try :O0OO0OOOOO000O00O .executebuiltin ("LoadProfile(Master user)")#line:465
    except :pass #line:466
    dialog .ok ('Step 1 complete','Change the skin to: [COLOR=lime]'+OOOO0000O000O000O ,'[/COLOR]Once done come back and choose install step 2 which will','re-install the guisettings.xml - this file contains all custom skin settings.')#line:467
    O0OO0OOOOO000O00O .executebuiltin ("ActivateWindow(appearancesettings)")#line:468
    CHECK_GUITEMP (OO000O00O00OOOO0O )#line:469
def CHECK_GUITEMP (O0000OO0O00OOOOO0 ):#line:470
    OO00O0OOO000O000O .sleep (120 )#line:471
    if O000OO00O00OOOO00 .path .exists (guitemp ):#line:472
        O0O0OO0OO0OOOO0O0 =O00O00OO0O0O0OO00 .Dialog ().yesno ('Run step 2 of install','You still haven\'t completed step 2 of the','install. Would you like to complete it now?','',nolabel ='No, not yet',yeslabel ='Yes, complete setup')#line:473
        if O0O0OO0OO0OOOO0O0 ==0 :#line:474
            CHECK_GUITEMP (O0000OO0O00OOOOO0 )#line:475
        elif O0O0OO0OO0OOOO0O0 ==1 :#line:476
            try :O0OO0OOOOO000O00O .executebuiltin ("PlayerControl(Stop)")#line:477
            except :pass #line:478
            O0OO0OOOOO000O00O .executebuiltin ("ActivateWindow(appearancesettings)")#line:479
            GUI_MERGE (O0000OO0O00OOOOO0 )#line:480
def CHECK_DOWNLOAD_PATH ():#line:481
    O0OOOO0O0OOO0O000 =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (zip ,'testCBFolder'))#line:482
    if not O000OO00O00OOOO00 .path .exists (zip ):#line:483
        dialog .ok ('[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds Tool','The download location you have stored does not exist .\nPlease update the addon settings and try again.','','')#line:484
        ADDON .openSettings (OO0000OO0OO00OO0O .argv [0 ])#line:485
def RESTORE_LOCAL_COMMUNITY ():#line:486
    import time as OO0O0OOO0OO00O0O0 #line:487
    OO0O0O000OOO00000 =0 #line:488
    OO000OOO00O000OOO =0 #line:489
    CHECK_DOWNLOAD_PATH ()#line:490
    OO0OO0000O00OO0O0 =O00O00OO0O0O0OO00 .Dialog ().browse (1 ,'Select the backup file you want to restore','files','.zip',False ,False ,USB )#line:491
    if OO0OO0000O00OO0O0 =='':#line:492
        return #line:493
    if O000OO00O00OOOO00 .path .exists (GUINEW ):#line:494
        if O000OO00O00OOOO00 .path .exists (GUI ):#line:495
            O000OO00O00OOOO00 .remove (GUINEW )#line:496
        else :#line:497
            O000OO00O00OOOO00 .rename (GUINEW ,GUI )#line:498
    if O000OO00O00OOOO00 .path .exists (GUIFIX ):#line:499
        O000OO00O00OOOO00 .remove (GUIFIX )#line:500
    if not O000OO00O00OOOO00 .path .exists (tempfile ):#line:501
        O000O0OO00OO00OO0 =open (tempfile ,mode ='w+')#line:502
    if O000OO00O00OOOO00 .path .exists (guitemp ):#line:503
        O000OO00O00OOOO00 .removedirs (guitemp )#line:504
    try :O000OO00O00OOOO00 .rename (GUI ,GUINEW )#line:505
    except :#line:506
        dialog .ok ("NO GUISETTINGS!",'No guisettings.xml file has been found.','Please exit XBMC and try again','')#line:507
        return #line:508
    O00O000OO00000O0O =O00O00OO0O0O0OO00 .Dialog ().yesno (name ,'We highly recommend backing up your existing build before','installing any builds.','Would you like to perform a backup first?',nolabel ='Backup',yeslabel ='Install')#line:509
    if O00O000OO00000O0O ==0 :#line:510
        O000O00OO0OOO0O00 =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USB ,'Daily Updates Builds','My Builds'))#line:511
        if not O000OO00O00OOOO00 .path .exists (O000O00OO0OOO0O00 ):#line:512
            O000OO00O00OOOO00 .makedirs (O000O00OO0OOO0O00 )#line:513
        O0O0O000OO0O00000 =_O0OO00OOO0000OOOO (heading ="Enter a name for this backup")#line:514
        if (not O0O0O000OO0O00000 ):return False ,0 #line:515
        OOO0O00OOOOOO0OO0 =O0OO0OOOOO0000000 .quote_plus (O0O0O000OO0O00000 )#line:516
        OO00OO0O0O0OO000O =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (O000O00OO0OOO0O00 ,OOO0O00OOOOOO0OO0 +'.zip'))#line:517
        O00OO0000O00O00O0 =['plugin.program.dailyupdateswiz']#line:518
        O0OO00OOO000O00OO =["xbmc.log","xbmc.old.log","kodi.log","kodi.old.log",'.DS_Store','.setup_complete','XBMCHelper.conf']#line:519
        OOOO00000OOO000OO ="Creating full backup of existing build"#line:520
        O0O00OO00OO0OOO0O ="Archiving..."#line:521
        OO0000O00OOOO0OOO =""#line:522
        OOOOOOO0OO000OO00 ="Please Wait"#line:523
        ARCHIVE_CB (HOME ,OO00OO0O0O0OO000O ,OOOO00000OOO000OO ,O0O00OO00OO0OOO0O ,OO0000O00OOOO0OOO ,OOOOOOO0OO000OO00 ,O00OO0000O00O00O0 ,O0OO00OOO000O00OO )#line:524
    OOO00OOOOO0OO0OO0 =O00O00OO0O0O0OO00 .Dialog ().yesno (name ,'Would you like to keep your existing database','files or overwrite? Overwriting will wipe any','existing music or video library you may have scanned in.',nolabel ='Overwrite',yeslabel ='Keep Existing')#line:525
    if OOO00OOOOO0OO0OO0 ==0 :pass #line:526
    elif OOO00OOOOO0OO0OO0 ==1 :#line:527
        if O000OO00O00OOOO00 .path .exists (tempdbpath ):#line:528
            O0O0O0O0O000000O0 .rmtree (tempdbpath )#line:529
        try :#line:530
            O0O0O0O0O000000O0 .copytree (DATABASE ,tempdbpath ,symlinks =False ,ignore =O0O0O0O0O000000O0 .ignore_patterns ("Textures13.db","Addons16.db","Addons15.db","saltscache.db-wal","saltscache.db-shm","saltscache.db","onechannelcache.db"))#line:531
        except :#line:532
            OO000OOO00O000OOO =O00O00OO0O0O0OO00 .Dialog ().yesno (name ,'There was an error trying to backup some databases.','Continuing may wipe your existing library. Do you','wish to continue?',nolabel ='No, cancel',yeslabel ='Yes, overwrite')#line:533
            if OO000OOO00O000OOO ==1 :pass #line:534
            if OO000OOO00O000OOO ==0 :OO0O0O000OOO00000 =1 ;return #line:535
        OO00OO0O0O0OO000O =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USB ,'Database.zip'))#line:536
        ARCHIVE_FILE (tempdbpath ,OO00OO0O0O0OO000O )#line:537
    if OO0O0O000OOO00000 ==1 :#line:538
        return #line:539
    else :#line:540
        OO0O0OOO0OO00O0O0 .sleep (1 )#line:541
        O000OO000000OOO0O =open (CBADDONPATH ,mode ='r')#line:542
        OOO0OO0000O00OO0O =O000OO000000OOO0O .read ()#line:543
        O000OO000000OOO0O .close ()#line:544
        READ_ZIP (OO0OO0000O00OO0O0 )#line:545
        dp .create ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds Tool","Checking ",'','Please Wait')#line:546
        dp .update (0 ,"","Extracting Zip Please Wait")#line:547
        OOOO000O0O0OO0000 .all (OO0OO0000O00OO0O0 ,HOME ,dp )#line:548
        OO0O0OOO0OO00O0O0 .sleep (1 )#line:549
        O00OOO0OOOOOOO0OO =O0OO0OOOOO0O00000 .basename (OO0OO0000O00OO0O0 )#line:550
        OOO0OO0000O0O0O00 =open (idfile ,mode ='w+')#line:551
        OOO0OO0000O0O0O00 .write ('id="none"\nname="'+O00OOO0OOOOOOO0OO +' [COLOR=yellow](Partially installed)[/COLOR]"\nversion="none"')#line:552
        OOO0OO0000O0O0O00 .close ()#line:553
        O0OOO0000O0O0O00O =open (CBADDONPATH ,mode ='w+')#line:554
        O0OOO0000O0O0O00O .write (OOO0OO0000O00OO0O )#line:555
        O0OOO0000O0O0O00O .close ()#line:556
        try :#line:557
            O000OO00O00OOOO00 .rename (GUI ,GUIFIX )#line:558
        except :#line:559
            print ('NO GUISETTINGS DOWNLOADED')#line:560
        OO0O0OOO0OO00O0O0 .sleep (1 )#line:561
        O000O0OO00OO00OO0 =open (GUINEW ,mode ='r')#line:562
        O0OOOOOO0000O00OO =file .read (O000O0OO00OO00OO0 )#line:563
        file .close (O000O0OO00OO00OO0 )#line:564
        OOO000000000O000O =O0O00OOOO0OOO00OO .compile ('<skinsettings>[\s\S]*?<\/skinsettings>').findall (O0OOOOOO0000O00OO )#line:565
        O00O000O00000000O =OOO000000000O000O [0 ]if (len (OOO000000000O000O )>0 )else ''#line:566
        OO0O0O000O0O0OOO0 =O0O00OOOO0OOO00OO .compile ('<skin default[\s\S]*?<\/skin>').findall (O0OOOOOO0000O00OO )#line:567
        O000OO0OO0OO00OOO =OO0O0O000O0O0OOO0 [0 ]if (len (OO0O0O000O0O0OOO0 )>0 )else ''#line:568
        O000O0000OOO0OO0O =O0O00OOOO0OOO00OO .compile ('<lookandfeel>[\s\S]*?<\/lookandfeel>').findall (O0OOOOOO0000O00OO )#line:569
        OOOO0OO00O0OO000O =O000O0000OOO0OO0O [0 ]if (len (O000O0000OOO0OO0O )>0 )else ''#line:570
        try :#line:571
            O0OOOO0O0O0000000 =open (GUIFIX ,mode ='r')#line:572
            OOOOOOO0O0O00OO0O =file .read (O0OOOO0O0O0000000 )#line:573
            file .close (O0OOOO0O0O0000000 )#line:574
            OO0OO0O0OO00OOOO0 =O0O00OOOO0OOO00OO .compile ('<skinsettings>[\s\S]*?<\/skinsettings>').findall (OOOOOOO0O0O00OO0O )#line:575
            OOO00O0O0OOO00OOO =OO0OO0O0OO00OOOO0 [0 ]if (len (OO0OO0O0OO00OOOO0 )>0 )else ''#line:576
            O0OOO0O0O0OO000O0 =O0O00OOOO0OOO00OO .compile ('<skin default[\s\S]*?<\/skin>').findall (OOOOOOO0O0O00OO0O )#line:577
            OOO000000O000OOOO =O0OOO0O0O0OO000O0 [0 ]if (len (O0OOO0O0O0OO000O0 )>0 )else ''#line:578
            O0000OO000O000000 =O0O00OOOO0OOO00OO .compile ('<lookandfeel>[\s\S]*?<\/lookandfeel>').findall (OOOOOOO0O0O00OO0O )#line:579
            OOOO0O0OOOOO0OOOO =O0000OO000O000000 [0 ]if (len (O0000OO000O000000 )>0 )else ''#line:580
            OO0O0O0O0OOO0O0OO =O0OOOOOO0000O00OO .replace (O00O000O00000000O ,OOO00O0O0OOO00OOO ).replace (OOOO0OO00O0OO000O ,OOOO0O0OOOOO0OOOO ).replace (O000OO0OO0OO00OOO ,OOO000000O000OOOO )#line:581
            OOO0OO0000O0O0O00 =open (GUINEW ,mode ='w+')#line:582
            OOO0OO0000O0O0O00 .write (str (OO0O0O0O0OOO0O0OO ))#line:583
            OOO0OO0000O0O0O00 .close ()#line:584
        except :#line:585
            print ('NO GUISETTINGS DOWNLOADED')#line:586
        if O000OO00O00OOOO00 .path .exists (GUI ):#line:587
            O000OO00O00OOOO00 .remove (GUI )#line:588
        O000OO00O00OOOO00 .rename (GUINEW ,GUI )#line:589
        try :#line:590
            O000OO00O00OOOO00 .remove (GUIFIX )#line:591
        except :#line:592
            pass #line:593
        if OOO00OOOOO0OO0OO0 ==1 :#line:594
            OOOO000O0O0OO0000 .all (OO00OO0O0O0OO000O ,DATABASE ,dp )#line:595
            if OO000OOO00O000OOO !=1 :#line:596
                O0O0O0O0O000000O0 .rmtree (tempdbpath )#line:597
        O000OO00O00OOOO00 .makedirs (guitemp )#line:598
        OO0O0OOO0OO00O0O0 .sleep (1 )#line:599
        O0OO0OOOOO000O00O .executebuiltin ('UnloadSkin()')#line:600
        OO0O0OOO0OO00O0O0 .sleep (1 )#line:601
        O0OO0OOOOO000O00O .executebuiltin ('ReloadSkin()')#line:602
        OO0O0OOO0OO00O0O0 .sleep (1 )#line:603
        O0OO0OOOOO000O00O .executebuiltin ("ActivateWindow(appearancesettings)")#line:604
        while O0OO0OOOOO000O00O .executebuiltin ("Window.IsActive(appearancesettings)"):#line:605
            O0OO0OOOOO000O00O .sleep (500 )#line:606
        try :O0OO0OOOOO000O00O .executebuiltin ("LoadProfile(Master user)")#line:607
        except :pass #line:608
        dialog .ok ('[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds Tool','Step 1 complete. Now please change the skin to','the one this build was designed for. Once done come back','to this addon and restore the guisettings_fix.zip')#line:609
        O0OO0OOOOO000O00O .executebuiltin ("ActivateWindow(appearancesettings)")#line:610
def RESTORE_LOCAL_GUI ():#line:611
    import time as OOOOO000O0O0O0OO0 #line:612
    CHECK_DOWNLOAD_PATH ()#line:613
    O000OO0000OO0O00O =O00O00OO0O0O0OO00 .Dialog ().browse (1 ,'Select the guisettings zip file you want to restore','files','.zip',False ,False ,USB )#line:614
    if O000OO0000OO0O00O =='':#line:615
        return #line:616
    else :#line:617
        OO0O0O000000O00OO =1 #line:618
        GUISETTINGS_FIX (O000OO0000OO0O00O ,OO0O0O000000O00OO )#line:619
def REMOVE_BUILD ():#line:620
    CHECK_DOWNLOAD_PATH ()#line:621
    O00OOO00OOOO0OOOO =O00O00OO0O0O0OO00 .Dialog ().browse (1 ,'Select the backup file you want to DELETE','files','.zip',False ,False ,USB )#line:622
    if O00OOO00OOOO0OOOO =='':#line:623
        return #line:624
    O0O00O0000OOOO00O =O0OO0OOOOO0O00000 .basename (O00OOO00OOOO0OOOO )#line:625
    OOO000OO0OO0000O0 =O00O00OO0O0O0OO00 .Dialog ().yesno ('Delete Backup File','This will completely remove '+O0O00O0000OOOO00O ,'Are you sure you want to delete?','',nolabel ='No, Cancel',yeslabel ='Yes, Delete')#line:626
    if OOO000OO0OO0000O0 ==0 :#line:627
        return #line:628
    elif OOO000OO0OO0000O0 ==1 :#line:629
        O000OO00O00OOOO00 .remove (O00OOO00OOOO0OOOO )#line:630
def killxbmc ():#line:631
    O0OO000OO0O00OOOO =O00O00OO0O0O0OO00 .Dialog ().yesno ('Force Close XBMC/Kodi','We will now attempt to force close Kodi, this is','to be used if having problems with guisettings.xml','sticking. Would you like to continue?',nolabel ='No, Cancel',yeslabel ='Yes, Close')#line:632
    if O0OO000OO0O00OOOO ==0 :#line:633
        return #line:634
    elif O0OO000OO0O00OOOO ==1 :#line:635
        pass #line:636
    OOOO0OO000OO0O0O0 =platform ()#line:637
    print ('Platform: '+str (OOOO0OO000OO0O0O0 ))#line:638
    if OOOO0OO000OO0O0O0 =='osx':#line:639
        print ('############   try osx force close  #################')#line:640
        try :O000OO00O00OOOO00 .system ('killall -9 XBMC')#line:641
        except :pass #line:642
        try :O000OO00O00OOOO00 .system ('killall -9 Kodi')#line:643
        except :pass #line:644
        dialog .ok ("[COLOR=red][B]WARNING  !!![/COLOR][/B]","If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')#line:645
    elif OOOO0OO000OO0O0O0 =='linux':#line:646
        print ('############   try linux force close  #################')#line:647
        try :O000OO00O00OOOO00 .system ('killall XBMC')#line:648
        except :pass #line:649
        try :O000OO00O00OOOO00 .system ('killall Kodi')#line:650
        except :pass #line:651
        try :O000OO00O00OOOO00 .system ('killall -9 xbmc.bin')#line:652
        except :pass #line:653
        try :O000OO00O00OOOO00 .system ('killall -9 kodi.bin')#line:654
        except :pass #line:655
        dialog .ok ("[COLOR=red][B]WARNING  !!![/COLOR][/B]","If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')#line:656
    elif OOOO0OO000OO0O0O0 =='android':#line:657
        print ("############   try android force close  #################")#line:658
        try :O000OO00O00OOOO00 .system ('adb shell am force-stop org.xbmc.kodi')#line:659
        except :pass #line:660
        try :O000OO00O00OOOO00 .system ('adb shell am force-stop org.kodi')#line:661
        except :pass #line:662
        try :O000OO00O00OOOO00 .system ('adb shell am force-stop org.xbmc.xbmc')#line:663
        except :pass #line:664
        try :O000OO00O00OOOO00 .system ('adb shell am force-stop org.xbmc')#line:665
        except :pass #line:666
        dialog .ok ("[COLOR=red][B]WARNING  !!![/COLOR][/B]","Your system has been detected as Android, you ","[COLOR=yellow][B]MUST[/COLOR][/B] force close XBMC/Kodi. [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Pulling the power cable is the simplest method to force close.")#line:667
    elif OOOO0OO000OO0O0O0 =='windows':#line:668
        print ("############   try windows force close  #################")#line:669
        try :#line:670
            O000OO00O00OOOO00 .system ('@ECHO off')#line:671
            O000OO00O00OOOO00 .system ('tskill XBMC.exe')#line:672
        except :pass #line:673
        try :#line:674
            O000OO00O00OOOO00 .system ('@ECHO off')#line:675
            O000OO00O00OOOO00 .system ('tskill Kodi.exe')#line:676
        except :pass #line:677
        try :#line:678
            O000OO00O00OOOO00 .system ('@ECHO off')#line:679
            O000OO00O00OOOO00 .system ('TASKKILL /im Kodi.exe /f')#line:680
        except :pass #line:681
        try :#line:682
            O000OO00O00OOOO00 .system ('@ECHO off')#line:683
            O000OO00O00OOOO00 .system ('TASKKILL /im XBMC.exe /f')#line:684
        except :pass #line:685
        dialog .ok ("[COLOR=red][B]WARNING  !!![/COLOR][/B]","If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")#line:686
    else :#line:687
        print ("############   try atv force close  #################")#line:688
        try :O000OO00O00OOOO00 .system ('killall AppleTV')#line:689
        except :pass #line:690
        print ("############   try raspbmc force close  #################")#line:691
        try :O000OO00O00OOOO00 .system ('sudo initctl stop kodi')#line:692
        except :pass #line:693
        try :O000OO00O00OOOO00 .system ('sudo initctl stop xbmc')#line:694
        except :pass #line:695
        dialog .ok ("[COLOR=red][B]WARNING  !!![/COLOR][/B]","If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","Your platform could not be detected so just pull the power cable.")#line:696
def Addon_Settings ():#line:697
    ADDON .openSettings (OO0000OO0OO00OO0O .argv [0 ])#line:698
def ADDITIONAL_TOOLS ():#line:699
    addDir ('Delete Builds From Device','url',81 ,'','','Delete Build')#line:700
    addDir ('Wipe My Setup (Fresh Start)','url',82 ,'','','Wipe your special XBMC/Kodi directory which will revert back to a vanillla build.')#line:701
    addDir ('Convert Physical Paths To Special',HOME ,83 ,'','','Convert Physical Paths To Special')#line:702
    addDir ('Check my download location','url',84 ,'','','Force close kodi, to be used as last resort')#line:703
    addDir ('Force Close Kodi','url',85 ,'','','Force close kodi, to be used as last resort')#line:704
def _O0OO00OOO0000OOOO (default ="",heading ="",hidden =False ):#line:705
    ""#line:706
    OOOO00O00OOO00OO0 =O0OO0OOOOO000O00O .Keyboard (default ,heading ,hidden )#line:707
    OOOO00O00OOO00OO0 .doModal ()#line:708
    if (OOOO00O00OOO00OO0 .isConfirmed ()):#line:709
        return unicode (OOOO00O00OOO00OO0 .getText (),"utf-8")#line:710
    return default #line:711
def BACKUP_OPTION ():#line:712
    addDir ('[COLOR=lime]Full Backup[/COLOR]','url',61 ,'Backup.png','','Back Up Your Full System')#line:713
    addDir ('Backup Just Your Addons','addons',62 ,'Backup.png','','Back Up Your Addons')#line:714
    addDir ('Backup Just Your Addon UserData','addon_data',62 ,'Backup.png','','Back Up Your Addon Userdata')#line:715
    addDir ('Backup Guisettings.xml',GUI ,64 ,'Backup.png','','Back Up Your guisettings.xml')#line:716
    if O000OO00O00OOOO00 .path .exists (FAVS ):#line:717
        addDir ('Backup Favourites.xml',FAVS ,64 ,'Backup.png','','Back Up Your favourites.xml')#line:718
    if O000OO00O00OOOO00 .path .exists (SOURCE ):#line:719
        addDir ('Backup Source.xml',SOURCE ,64 ,'Backup.png','','Back Up Your sources.xml')#line:720
    if O000OO00O00OOOO00 .path .exists (ADVANCED ):#line:721
        addDir ('Backup Advancedsettings.xml',ADVANCED ,64 ,'Backup.png','','Back Up Your advancedsettings.xml')#line:722
    if O000OO00O00OOOO00 .path .exists (KEYMAPS ):#line:723
        addDir ('Backup Advancedsettings.xml',KEYMAPS ,64 ,'Backup.png','','Back Up Your keyboard.xml')#line:724
    if O000OO00O00OOOO00 .path .exists (RSS ):#line:725
        addDir ('Backup RssFeeds.xml',RSS ,64 ,'Backup.png','','Back Up Your RssFeeds.xml')#line:726
def CHECK_LOCAL_INSTALL ():#line:727
    OO00OOO0OOO00OO00 =open (idfile ,mode ='r')#line:728
    OOOO0OOO000O00000 =file .read (OO00OOO0OOO00OO00 )#line:729
    file .close (OO00OOO0OOO00OO00 )#line:730
    OO0OO000O0O0000O0 =O0O00OOOO0OOO00OO .compile ('name="(.+?)"').findall (OOOO0OOO000O00000 )#line:731
    O00O0OO0O00OO0OO0 =OO0OO000O0O0000O0 [0 ]if (len (OO0OO000O0O0000O0 )>0 )else ''#line:732
    if O00O0OO0O00OO0OO0 =="Incomplete":#line:733
        O0OOOO0O00OO00O00 =O00O00OO0O0O0OO00 .Dialog ().yesno ("Finish Restore Process",'If you\'re certain the correct skin has now been set click OK','to finish the install process, once complete XBMC/Kodi will',' then close. Do you want to finish the install process?',yeslabel ='Yes',nolabel ='No')#line:734
        if O0OOOO0O00OO00O00 ==1 :#line:735
            FINISH_LOCAL_RESTORE ()#line:736
        elif O0OOOO0O00OO00O00 ==0 :#line:737
            return #line:738
def FINISH_LOCAL_RESTORE ():#line:739
    O000OO00O00OOOO00 .remove (idfile )#line:740
    O000OO00O00OOOO00 .rename (idfiletemp ,idfile )#line:741
    O0OO0OOOOO000O00O .executebuiltin ('UnloadSkin')#line:742
    O0OO0OOOOO000O00O .executebuiltin ("ReloadSkin")#line:743
    dialog .ok ("Local Restore Complete",'XBMC/Kodi will now close.','','')#line:744
    O0OO0OOOOO000O00O .executebuiltin ("Quit")#line:745
def LocalGUIDialog ():#line:746
    dialog .ok ("Restore local guisettings fix","You should [COLOR=lime]ONLY[/COLOR] use this option if the guisettings fix","is failing to download via the addon. Installing via this","method will mean you do not receive any updates")#line:747
    RESTORE_LOCAL_GUI ()#line:748
def RESTORE_OPTION ():#line:749
    CHECK_LOCAL_INSTALL ()#line:750
    addDir ('[COLOR=lime]RESTORE LOCAL BUILD[/COLOR]','url',71 ,'Restore.png','','Back Up Your Full System')#line:751
    addDir ('[COLOR=dodgerblue]Restore Local guisettings file[/COLOR]','url',72 ,'Restore.png','','Back Up Your Full System')#line:752
    if O000OO00O00OOOO00 .path .exists (O000OO00O00OOOO00 .path .join (USB ,'addons.zip')):#line:753
        addDir ('Restore Your Addons','addons','restore_zip','Restore.png','','','Restore Your Addons')#line:754
    if O000OO00O00OOOO00 .path .exists (O000OO00O00OOOO00 .path .join (USB ,'addon_data.zip')):#line:755
        addDir ('Restore Your Addon UserData','addon_data','restore_zip','Restore.png','','','Restore Your Addon UserData')#line:756
    if O000OO00O00OOOO00 .path .exists (O000OO00O00OOOO00 .path .join (USB ,'guisettings.xml')):#line:757
        addDir ('Restore Guisettings.xml',GUI ,'resore_backup','Restore.png','','','Restore Your guisettings.xml')#line:758
    if O000OO00O00OOOO00 .path .exists (O000OO00O00OOOO00 .path .join (USB ,'favourites.xml')):#line:759
        addDir ('Restore Favourites.xml',FAVS ,'resore_backup','Restore.png','','','Restore Your favourites.xml')#line:760
    if O000OO00O00OOOO00 .path .exists (O000OO00O00OOOO00 .path .join (USB ,'sources.xml')):#line:761
        addDir ('Restore Source.xml',SOURCE ,'resore_backup','Restore.png','','','Restore Your sources.xml')#line:762
    if O000OO00O00OOOO00 .path .exists (O000OO00O00OOOO00 .path .join (USB ,'advancedsettings.xml')):#line:763
        addDir ('Restore Advancedsettings.xml',ADVANCED ,'resore_backup','Restore.png','','','Restore Your advancedsettings.xml')#line:764
    if O000OO00O00OOOO00 .path .exists (O000OO00O00OOOO00 .path .join (USB ,'keyboard.xml')):#line:765
        addDir ('Restore Advancedsettings.xml',KEYMAPS ,'resore_backup','Restore.png','','','Restore Your keyboard.xml')#line:766
    if O000OO00O00OOOO00 .path .exists (O000OO00O00OOOO00 .path .join (USB ,'RssFeeds.xml')):#line:767
        addDir ('Restore RssFeeds.xml',RSS ,'resore_backup','Restore.png','','','Restore Your RssFeeds.xml')#line:768
def RESTORE_ZIP_FILE (OO000O0000000OOO0 ):#line:769
    CHECK_DOWNLOAD_PATH ()#line:770
    if 'addons'in OO000O0000000OOO0 :#line:771
        OO000OOO00OO0O00O =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USB ,'addons.zip'))#line:772
        O000O0O0O000O0000 =ADDONS #line:773
        O0O00O00OO0O0000O =ADDONS #line:774
        O00O000OO00OOO00O =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USB ,'addons.zip'))#line:775
    else :#line:776
        OO000OOO00OO0O00O =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USB ,'addon_data.zip'))#line:777
        O000O0O0O000O0000 =ADDON_DATA #line:778
    if 'Backup'in name :#line:779
        DeletePackages2 ()#line:780
        import zipfile as OO00O00000OO00O00 #line:781
        import sys as OO00000000O0000O0 #line:782
        dp .create ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds Tool","Backing Up",'','Please Wait')#line:783
        OOO00O000OOO0OO00 =OO00O00000OO00O00 .ZipFile (OO000OOO00OO0O00O ,'w',OO00O00000OO00O00 .ZIP_DEFLATED )#line:784
        O000O0OOO00000OO0 =len (O000O0O0O000O0000 )#line:785
        O00O0OOO0O0O0000O =[]#line:786
        OOO00OO0OO00O0O0O =[]#line:787
        for O00000O0O0000OOOO ,O0O0OO0OO0O00O0OO ,O0000O000OO0O0O00 in O000OO00O00OOOO00 .walk (O000O0O0O000O0000 ):#line:788
            for OO0OOO000OOO0OOOO in O0000O000OO0O0O00 :#line:789
                OOO00OO0OO00O0O0O .append (OO0OOO000OOO0OOOO )#line:790
        OO00O00O0000OOO00 =len (OOO00OO0OO00O0O0O )#line:791
        for O00000O0O0000OOOO ,O0O0OO0OO0O00O0OO ,O0000O000OO0O0O00 in O000OO00O00OOOO00 .walk (O000O0O0O000O0000 ):#line:792
            for OO0OOO000OOO0OOOO in O0000O000OO0O0O00 :#line:793
                O00O0OOO0O0O0000O .append (OO0OOO000OOO0OOOO )#line:794
                OO0OOO0O000O0O0O0 =len (O00O0OOO0O0O0000O )/float (OO00O00O0000OOO00 )*100 #line:795
                dp .update (int (OO0OOO0O000O0O0O0 ),"Backing Up",'[COLOR yellow]%s[/COLOR]'%OO0OOO000OOO0OOOO ,'Please Wait')#line:796
                OOOO00OOOOOOOOOOO =O000OO00O00OOOO00 .path .join (O00000O0O0000OOOO ,OO0OOO000OOO0OOOO )#line:797
                if not 'temp'in O0O0OO0OO0O00O0OO :#line:798
                    if not 'plugin.program.dailyupdateswiz'in O0O0OO0OO0O00O0OO :#line:799
                       import time as O000O0OOO0OOOOO0O #line:800
                       O00OOO000OO0O00OO ='01/01/1980'#line:801
                       O00000OO000O00O00 =O000O0OOO0OOOOO0O .strftime ('%d/%m/%Y',O000O0OOO0OOOOO0O .gmtime (O000OO00O00OOOO00 .path .getmtime (OOOO00OOOOOOOOOOO )))#line:802
                       if O00000OO000O00O00 >O00OOO000OO0O00OO :#line:803
                           OOO00O000OOO0OO00 .write (OOOO00OOOOOOOOOOO ,OOOO00OOOOOOOOOOO [O000O0OOO00000OO0 :])#line:804
        OOO00O000OOO0OO00 .close ()#line:805
        dp .close ()#line:806
        dialog .ok ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds Tool","You Are Now Backed Up",'','')#line:807
    else :#line:808
        dp .create ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds Tool","Checking ",'','Please Wait')#line:809
        import time as O000O0OOO0OOOOO0O #line:810
        dp .update (0 ,"","Extracting Zip Please Wait")#line:811
        OOOO000O0O0OO0000 .all (OO000OOO00OO0O00O ,O000O0O0O000O0000 ,dp )#line:812
        O000O0OOO0OOOOO0O .sleep (1 )#line:813
        O0OO0OOOOO000O00O .executebuiltin ('UpdateLocalAddons ')#line:814
        O0OO0OOOOO000O00O .executebuiltin ("UpdateAddonRepos")#line:815
        if 'Backup'in name :#line:816
            killxbmc ()#line:817
            dialog .ok ("Daily Updates Builds - Install Complete",'To ensure the skin settings are set correctly XBMC will now','close. If XBMC doesn\'t close please force close (pull power','or force close in your OS - [COLOR=lime]DO NOT exit via XBMC menu[/COLOR])')#line:818
        else :#line:819
            dialog .ok ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds Tool","You Are Now Restored",'','')#line:820
def RESTORE_BACKUP_XML (OOOOOOOO0OOO000OO ,O00OOO0O000O00OOO ,OO000OO00OOOO00OO ):#line:821
    if 'Backup'in OOOOOOOO0OOO000OO :#line:822
        OOO00000OO0000000 =open (O00OOO0O000O00OOO ).read ()#line:823
        OO0O00O00O00O0000 =O000OO00O00OOOO00 .path .join (USB ,OO000OO00OOOO00OO .split ('Your ')[1 ])#line:824
        OOO00OOOO0OOO0O0O =open (OO0O00O00O00O0000 ,mode ='w')#line:825
        OOO00OOOO0OOO0O0O .write (OOO00000OO0000000 )#line:826
        OOO00OOOO0OOO0O0O .close ()#line:827
    else :#line:828
        if 'guisettings.xml'in OO000OO00OOOO00OO :#line:829
            O0O0O000O000OO000 =open (O000OO00O00OOOO00 .path .join (USB ,OO000OO00OOOO00OO .split ('Your ')[1 ])).read ()#line:830
            OO0000OO00OOOO000 ='<setting type="(.+?)" name="%s.(.+?)">(.+?)</setting>'%skin #line:831
            OOOOO00O000OO0O0O =O0O00OOOO0OOO00OO .compile (OO0000OO00OOOO000 ).findall (O0O0O000O000OO000 )#line:832
            for O00O00OO0OO0O00OO ,OOO00000O00OO0OOO ,O000OO0000OOO000O in OOOOO00O000OO0O0O :#line:833
                O000OO0000OOO000O =O000OO0000OOO000O .replace ('&quot;','').replace ('&amp;','&')#line:834
                O0OO0OOOOO000O00O .executebuiltin ("Skin.Set%s(%s,%s)"%(O00O00OO0OO0O00OO .title (),OOO00000O00OO0OOO ,O000OO0000OOO000O ))#line:835
        else :#line:836
            OO0O00O00O00O0000 =O000OO00O00OOOO00 .path .join (O00OOO0O000O00OOO )#line:837
            OOO00000OO0000000 =open (O000OO00O00OOOO00 .path .join (USB ,OO000OO00OOOO00OO .split ('Your ')[1 ])).read ()#line:838
            OOO00OOOO0OOO0O0O =open (OO0O00O00O00O0000 ,mode ='w')#line:839
            OOO00OOOO0OOO0O0O .write (OOO00000OO0000000 )#line:840
            OOO00OOOO0OOO0O0O .close ()#line:841
    dialog .ok ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds Tool","",'All Done !','')#line:842
def DeletePackages2 ():#line:843
    print ('############################################################       DELETING PACKAGES             ###############################################################')#line:844
    O0O0OO00OO00O0000 =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('special://home/addons/packages',''))#line:845
    for O00000OO0O000OOOO ,O000O0O0OOOOOO0O0 ,OO00OOO0OOO000OO0 in O000OO00O00OOOO00 .walk (O0O0OO00OO00O0000 ):#line:846
        O000O00O0OO0OO000 =0 #line:847
        O000O00O0OO0OO000 +=len (OO00OOO0OOO000OO0 )#line:848
        if O000O00O0OO0OO000 >0 :#line:849
            for OO0OOOOOO00OO00OO in OO00OOO0OOO000OO0 :#line:850
                O000OO00O00OOOO00 .unlink (O000OO00O00OOOO00 .path .join (O00000OO0O000OOOO ,OO0OOOOOO00OO00OO ))#line:851
            for O0O0O000000OOOOO0 in O000O0O0OOOOOO0O0 :#line:852
                O0O0O0O0O000000O0 .rmtree (O000OO00O00OOOO00 .path .join (O00000OO0O000OOOO ,O0O0O000000OOOOO0 ))#line:853
def DeleteUserData ():#line:854
    print ('############################################################       DELETING USERDATA             ###############################################################')#line:855
    O00O0000OO0OO0OOO =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('special://home/userdata/addon_data',''))#line:856
    for O000O00O00O0OO0O0 ,O000O000OO0O00000 ,OOOO0O00OO00O000O in O000OO00O00OOOO00 .walk (O00O0000OO0OO0OOO ):#line:857
        O0000O000OO0OO0OO =0 #line:858
        O0000O000OO0OO0OO +=len (OOOO0O00OO00O000O )#line:859
        if O0000O000OO0OO0OO >=0 :#line:860
            for O00O00O0OOO0OOOOO in OOOO0O00OO00O000O :#line:861
                O000OO00O00OOOO00 .unlink (O000OO00O00OOOO00 .path .join (O000O00O00O0OO0O0 ,O00O00O0OOO0OOOOO ))#line:862
            for OOOO00O00OOO0O000 in O000O000OO0O00000 :#line:863
                O0O0O0O0O000000O0 .rmtree (O000OO00O00OOOO00 .path .join (O000O00O00O0OO0O0 ,OOOO00O00OOO0O000 ))#line:864
def WipeXBMC ():#line:865
    if skin !="skin.confluence":#line:866
        dialog .ok ('[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds Tool','Please switch to the default Confluence skin','before performing a wipe.','')#line:867
        O0OO0OOOOO000O00O .executebuiltin ("ActivateWindow(appearancesettings)")#line:868
        return #line:869
    else :#line:870
        OOO0OO0O0OO0OOOO0 =O00O00OO0O0O0OO00 .Dialog ().yesno ("VERY IMPORTANT",'This will completely wipe your install.','Would you like to create a backup before proceeding?','',yeslabel ='Yes',nolabel ='No')#line:871
        if OOO0OO0O0OO0OOOO0 ==1 :#line:872
            O00OO0OOOOOOOO0O0 =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (USB ,'Daily Updates Builds','My Builds'))#line:873
            if not O000OO00O00OOOO00 .path .exists (O00OO0OOOOOOOO0O0 ):#line:874
                O000OO00O00OOOO00 .makedirs (O00OO0OOOOOOOO0O0 )#line:875
            OOO0O00OO00OO0O00 =_O0OO00OOO0000OOOO (heading ="Enter a name for this backup")#line:876
            if (not OOO0O00OO00OO0O00 ):return False ,0 #line:877
            O0OO0000O0OO0OO00 =O0OO0OOOOO0000000 .quote_plus (OOO0O00OO00OO0O00 )#line:878
            O0O00OO00O00OO0OO =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join (O00OO0OOOOOOOO0O0 ,O0OO0000O0OO0OO00 +'.zip'))#line:879
            OOO0O0O00O0OOOO00 =["plugin.program.dailyupdateswiz","plugin.video.infadroidwizard"]#line:880
            OOOOO0O0O0O0O0O0O =["xbmc.log","xbmc.old.log","kodi.log","kodi.old.log",'.DS_Store','.setup_complete','XBMCHelper.conf']#line:881
            OOOO0OO0OOOOOOO00 ="Creating full backup of existing build"#line:882
            O00000OOO00O0O00O ="Archiving..."#line:883
            O0O0O0O0OOO00O00O =""#line:884
            OO0OOO00OO0OOO00O ="Please Wait"#line:885
            ARCHIVE_CB (HOME ,O0O00OO00O00OO0OO ,OOOO0OO0OOOOOOO00 ,O00000OOO00O0O00O ,O0O0O0O0OOO00O00O ,OO0OOO00OO0OOO00O ,OOO0O0O00O0OOOO00 ,OOOOO0O0O0O0O0O0O )#line:886
    OOO0OO0OO0OO0OO00 =O00O00OO0O0O0OO00 .Dialog ().yesno ("ABSOLUTELY CERTAIN?!!!",'Are you absolutely certain you want to wipe this install?','','All addons and settings will be completely wiped!',yeslabel ='Yes',nolabel ='No')#line:887
    if OOO0OO0OO0OO0OO00 ==0 :#line:888
        return #line:889
    elif OOO0OO0OO0OO0OO00 ==1 :#line:890
        dp .create ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds Tool","Wiping Install",'','Please Wait')#line:891
        try :#line:892
            for O0O0000OOOOO0OOOO ,O00OOO0O0OO0OO0OO ,OO0O0000O00OOO00O in O000OO00O00OOOO00 .walk (HOME ,topdown =True ):#line:893
                O00OOO0O0OO0OO0OO [:]=[O00O000O000000O0O for O00O000O000000O0O in O00OOO0O0OO0OO0OO if O00O000O000000O0O not in EXCLUDES ]#line:894
                for OO00OO0OO00OO0000 in OO0O0000O00OOO00O :#line:895
                    try :#line:896
                        O000OO00O00OOOO00 .remove (O000OO00O00OOOO00 .path .join (O0O0000OOOOO0OOOO ,OO00OO0OO00OO0000 ))#line:897
                        O000OO00O00OOOO00 .rmdir (O000OO00O00OOOO00 .path .join (O0O0000OOOOO0OOOO ,OO00OO0OO00OO0000 ))#line:898
                    except :pass #line:899
                for OO00OO0OO00OO0000 in O00OOO0O0OO0OO0OO :#line:900
                    try :O000OO00O00OOOO00 .rmdir (O000OO00O00OOOO00 .path .join (O0O0000OOOOO0OOOO ,OO00OO0OO00OO0000 ));O000OO00O00OOOO00 .rmdir (O0O0000OOOOO0OOOO )#line:901
                    except :pass #line:902
        except :pass #line:903
    REMOVE_EMPTY_FOLDERS ()#line:904
    REMOVE_EMPTY_FOLDERS ()#line:905
    REMOVE_EMPTY_FOLDERS ()#line:906
    REMOVE_EMPTY_FOLDERS ()#line:907
    REMOVE_EMPTY_FOLDERS ()#line:908
    REMOVE_EMPTY_FOLDERS ()#line:909
    REMOVE_EMPTY_FOLDERS ()#line:910
    dialog .ok ('[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds Tool','Wipe Successful, please restart XBMC/Kodi for changes to take effect.','','')#line:911
def REMOVE_EMPTY_FOLDERS ():#line:912
    print ("########### Start Removing Empty Folders #########")#line:913
    O00O0000OOOO00O00 =0 #line:914
    O0O000OO0OOO00O00 =0 #line:915
    for O0O00OOO0O0O0OOOO ,O00000000O0O00000 ,O0O0OOO0O0000OO00 in O000OO00O00OOOO00 .walk (HOME ):#line:916
        if len (O00000000O0O00000 )==0 and len (O0O0OOO0O0000OO00 )==0 :#line:917
            O00O0000OOOO00O00 +=1 #line:918
            O000OO00O00OOOO00 .rmdir (O0O00OOO0O0O0OOOO )#line:919
            print ("successfully removed: ")+O0O00OOO0O0O0OOOO #line:920
        elif len (O00000000O0O00000 )>0 and len (O0O0OOO0O0000OO00 )>0 :#line:921
            O0O000OO0OOO00O00 +=1 #line:922
def WipeInstall ():#line:923
    if skin !="skin.confluence":#line:924
        dialog .ok ('[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds Tool','Please switch to the default Confluence skin','before performing a wipe.','')#line:925
        O0OO0OOOOO000O00O .executebuiltin ("ActivateWindow(appearancesettings)")#line:926
    else :#line:927
        OOOOO0O00O00OO000 =O00O00OO0O0O0OO00 .Dialog ().yesno ("ABSOLUTELY CERTAIN?!!!",'Are you absolutely certain you want to wipe this install?','','All addons and settings will be completely wiped!',yeslabel ='Yes',nolabel ='No')#line:928
        if OOOOO0O00O00OO000 ==0 :#line:929
            return #line:930
        elif OOOOO0O00O00OO000 ==1 :#line:931
            dp .create ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR][COLOR blue]Team[/COLOR] Builds Tool","Wiping Install",'','Please Wait')#line:932
            OO00OOOOOOO0000O0 =OO00OO0OO00O00000 .Addon (id =AddonID ).getAddonInfo ('path');OO00OOOOOOO0000O0 =O0OO0OOOOO000O00O .translatePath (OO00OOOOOOO0000O0 );#line:933
            OO0OO00O0O00OOOO0 =O000OO00O00OOOO00 .path .join (OO00OOOOOOO0000O0 ,"..","..");OO0OO00O0O00OOOO0 =O000OO00O00OOOO00 .path .abspath (OO0OO00O0O00OOOO0 );O00OO0O0000O00OOO =False #line:934
            try :#line:935
                for OOO0O0OOO0O0O00O0 ,O00OO00000OO00OOO ,OOO0O0OO0O000000O in O000OO00O00OOOO00 .walk (OO0OO00O0O00OOOO0 ,topdown =True ):#line:936
                    O00OO00000OO00OOO [:]=[O0OO00000O00000OO for O0OO00000O00000OO in O00OO00000OO00OOO if O0OO00000O00000OO not in EXCLUDES ]#line:937
                    for O0O00O0O000OOO000 in OOO0O0OO0O000000O :#line:938
                        try :O000OO00O00OOOO00 .remove (O000OO00O00OOOO00 .path .join (OOO0O0OOO0O0O00O0 ,O0O00O0O000OOO000 ))#line:939
                        except :pass #line:940
                    for O0O00O0O000OOO000 in O00OO00000OO00OOO :#line:941
                        try :O000OO00O00OOOO00 .rmdir (O000OO00O00OOOO00 .path .join (OOO0O0OOO0O0O00O0 ,O0O00O0O000OOO000 ))#line:942
                        except :pass #line:943
            except :pass #line:944
        REMOVE_EMPTY_FOLDERS ()#line:945
        REMOVE_EMPTY_FOLDERS ()#line:946
        REMOVE_EMPTY_FOLDERS ()#line:947
        REMOVE_EMPTY_FOLDERS ()#line:948
        REMOVE_EMPTY_FOLDERS ()#line:949
        REMOVE_EMPTY_FOLDERS ()#line:950
        REMOVE_EMPTY_FOLDERS ()#line:951
def get_params ():#line:952
        OO0O00OO00O00OOO0 =[]#line:953
        OOOO00O0000O000O0 =OO0000OO0OO00OO0O .argv [2 ]#line:954
        if len (OOOO00O0000O000O0 )>=2 :#line:955
                O0O0000O0O0OO000O =OO0000OO0OO00OO0O .argv [2 ]#line:956
                OO00000O0O0OO0OO0 =O0O0000O0O0OO000O .replace ('?','')#line:957
                if (O0O0000O0O0OO000O [len (O0O0000O0O0OO000O )-1 ]=='/'):#line:958
                        O0O0000O0O0OO000O =O0O0000O0O0OO000O [0 :len (O0O0000O0O0OO000O )-2 ]#line:959
                OO0000000O0OO0OO0 =OO00000O0O0OO0OO0 .split ('&')#line:960
                OO0O00OO00O00OOO0 ={}#line:961
                for OO0O0O0O000O00000 in range (len (OO0000000O0OO0OO0 )):#line:962
                        O0O0O000000OOO00O ={}#line:963
                        O0O0O000000OOO00O =OO0000000O0OO0OO0 [OO0O0O0O000O00000 ].split ('=')#line:964
                        if (len (O0O0O000000OOO00O ))==2 :#line:965
                                OO0O00OO00O00OOO0 [O0O0O000000OOO00O [0 ]]=O0O0O000000OOO00O [1 ]#line:966
        return OO0O00OO00O00OOO0 #line:967
def addDirectoryItem (OOOO0O00O000O0000 ,OOOO0OO0OO0OOOOO0 ,O0OO00O0O000OOO00 ,OOOO0OO0O000OOOO0 ):#line:968
    OOOOO0000O00OOOOO .addDirectoryItem (OOOO0O00O000O0000 ,OOOO0OO0OO0OOOOO0 ,O0OO00O0O000OOO00 ,OOOO0OO0O000OOOO0 )#line:969
def addBuildDir (OO0O00O0OO0OO0OO0 ,O0OO000OO0OOOO000 ,O00000OO0000OOOOO ,O0OOOO0OO0O0OOO00 ,O000O00OO00OO00O0 ,OO0O0OO000O00OO0O ,OOO0O0O00O0O000O0 ,OOO0OO0OO0O0O0O00 ,OOOOOO00O00OO0OOO ):#line:970
        OOOOOO0O0OOO000O0 =OO0000OO0OO00OO0O .argv [0 ]+"?url="+O0OO0OOOOO0000000 .quote_plus (O0OO000OO0OOOO000 )+"&mode="+str (O00000OO0000OOOOO )+"&name="+O0OO0OOOOO0000000 .quote_plus (OO0O00O0OO0OO0OO0 )+"&iconimage="+O0OO0OOOOO0000000 .quote_plus (O0OOOO0OO0O0OOO00 )+"&fanart="+O0OO0OOOOO0000000 .quote_plus (O000O00OO00OO00O0 )+"&video="+O0OO0OOOOO0000000 .quote_plus (OO0O0OO000O00OO0O )+"&description="+O0OO0OOOOO0000000 .quote_plus (OOO0O0O00O0O000O0 )+"&skins="+O0OO0OOOOO0000000 .quote_plus (OOO0OO0OO0O0O0O00 )+"&guisettingslink="+O0OO0OOOOO0000000 .quote_plus (OOOOOO00O00OO0OOO )#line:971
        O0O0O0O0O0000OOO0 =True #line:972
        OO0O00000O0000O00 =O00O00OO0O0O0OO00 .ListItem (OO0O00O0OO0OO0OO0 ,iconImage ="DefaultFolder.png",thumbnailImage =O0OOOO0OO0O0OOO00 )#line:973
        OO0O00000O0000O00 .setInfo (type ="Video",infoLabels ={"Title":OO0O00O0OO0OO0OO0 ,"Plot":OOO0O0O00O0O000O0 })#line:974
        OO0O00000O0000O00 .setProperty ("Fanart_Image",O000O00OO00OO00O0 )#line:975
        OO0O00000O0000O00 .setProperty ("Build.Video",OO0O0OO000O00OO0O )#line:976
        if (O00000OO0000OOOOO ==None )or (O00000OO0000OOOOO =='restore_option')or (O00000OO0000OOOOO =='backup_option')or (O00000OO0000OOOOO =='cb_root_menu')or (O00000OO0000OOOOO =='genres')or (O00000OO0000OOOOO =='grab_builds')or (O00000OO0000OOOOO =='community_menu')or (O00000OO0000OOOOO =='instructions')or (O00000OO0000OOOOO =='countries')or (O0OO000OO0OOOO000 ==None )or (len (O0OO000OO0OOOO000 )<1 ):#line:977
            O0O0O0O0O0000OOO0 =OOOOO0000O00OOOOO .addDirectoryItem (handle =int (OO0000OO0OO00OO0O .argv [1 ]),url =OOOOOO0O0OOO000O0 ,listitem =OO0O00000O0000O00 ,isFolder =True )#line:978
        else :#line:979
            O0O0O0O0O0000OOO0 =OOOOO0000O00OOOOO .addDirectoryItem (handle =int (OO0000OO0OO00OO0O .argv [1 ]),url =OOOOOO0O0OOO000O0 ,listitem =OO0O00000O0000O00 ,isFolder =False )#line:980
        return O0O0O0O0O0000OOO0 #line:981
def addDescDir (OOO0O0O00O000OOO0 ,O0O0O00OO0OOOO00O ,O000OO00O0O0OO000 ,O00OO0O0O00O0OO0O ,OOOO00O000O00O0OO ,OOO00000O0000O000 ,O0O0O000O00000O0O ,OO0OOO0O00OO0000O ,OOO00000OO00000OO ,O0O00O000O0OO0OO0 ,OO000O0OO0OO0OO00 ,O0000OOOO000O0O0O ,O00OO0O0O0OO000O0 ,OOOO0O0O0O0OO0O00 ,O0OOOO0OO000OOOOO ,OOO00O000OO00O00O ,OO0O00O0OO00O00OO ):#line:982
        O00OO0O0O00O0OO0O =ARTPATH +O00OO0O0O00O0OO0O #line:983
        OOOO0000OOOO0000O =OO0000OO0OO00OO0O .argv [0 ]+"?url="+O0OO0OOOOO0000000 .quote_plus (O0O0O00OO0OOOO00O )+"&mode="+str (O000OO00O0O0OO000 )+"&name="+O0OO0OOOOO0000000 .quote_plus (OOO0O0O00O000OOO0 )+"&iconimage="+O0OO0OOOOO0000000 .quote_plus (O00OO0O0O00O0OO0O )+"&fanart="+O0OO0OOOOO0000000 .quote_plus (OOOO00O000O00O0OO )+"&author="+O0OO0OOOOO0000000 .quote_plus (O0O0O000O00000O0O )+"&description="+O0OO0OOOOO0000000 .quote_plus (OOO00000OO00000OO )+"&version="+O0OO0OOOOO0000000 .quote_plus (OO0OOO0O00OO0000O )+"&buildname="+O0OO0OOOOO0000000 .quote_plus (OOO00000O0000O000 )+"&updated="+O0OO0OOOOO0000000 .quote_plus (O0O00O000O0OO0OO0 )+"&skins="+O0OO0OOOOO0000000 .quote_plus (OO000O0OO0OO0OO00 )+"&videoaddons="+O0OO0OOOOO0000000 .quote_plus (O0000OOOO000O0O0O )+"&audioaddons="+O0OO0OOOOO0000000 .quote_plus (O00OO0O0O0OO000O0 )+"&buildname="+O0OO0OOOOO0000000 .quote_plus (OOO00000O0000O000 )+"&programaddons="+O0OO0OOOOO0000000 .quote_plus (OOOO0O0O0O0OO0O00 )+"&pictureaddons="+O0OO0OOOOO0000000 .quote_plus (O0OOOO0OO000OOOOO )+"&sources="+O0OO0OOOOO0000000 .quote_plus (OOO00O000OO00O00O )+"&adult="+O0OO0OOOOO0000000 .quote_plus (OO0O00O0OO00O00OO )#line:984
        OO0OO0O00O0O0O00O =True #line:985
        OO0OO0O000OO00O0O =O00O00OO0O0O0OO00 .ListItem (OOO0O0O00O000OOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =O00OO0O0O00O0OO0O )#line:986
        OO0OO0O000OO00O0O .setInfo (type ="Video",infoLabels ={"Title":OOO0O0O00O000OOO0 ,"Plot":OOO00000OO00000OO })#line:987
        OO0OO0O000OO00O0O .setProperty ("Fanart_Image",OOOO00O000O00O0OO )#line:988
        OO0OO0O000OO00O0O .setProperty ("Build.Video",video )#line:989
        OO0OO0O00O0O0O00O =OOOOO0000O00OOOOO .addDirectoryItem (handle =int (OO0000OO0OO00OO0O .argv [1 ]),url =OOOO0000OOOO0000O ,listitem =OO0OO0O000OO00O0O ,isFolder =False )#line:990
        return OO0OO0O00O0O0O00O #line:991
def platform ():#line:992
    if O0OO0OOOOO000O00O .getCondVisibility ('system.platform.android'):#line:993
        return 'android'#line:994
    elif O0OO0OOOOO000O00O .getCondVisibility ('system.platform.linux'):#line:995
        return 'linux'#line:996
    elif O0OO0OOOOO000O00O .getCondVisibility ('system.platform.windows'):#line:997
        return 'windows'#line:998
    elif O0OO0OOOOO000O00O .getCondVisibility ('system.platform.osx'):#line:999
        return 'osx'#line:1000
    elif O0OO0OOOOO000O00O .getCondVisibility ('system.platform.atv2'):#line:1001
        return 'atv2'#line:1002
    elif O0OO0OOOOO000O00O .getCondVisibility ('system.platform.ios'):#line:1003
        return 'ios'#line:1004
params =get_params ()#line:1005
url =None #line:1006
name =None #line:1007
buildname =None #line:1008
updated =None #line:1009
author =None #line:1010
version =None #line:1011
mode =None #line:1012
iconimage =None #line:1013
description =None #line:1014
video =None #line:1015
link =None #line:1016
skins =None #line:1017
videoaddons =None #line:1018
audioaddons =None #line:1019
programaddons =None #line:1020
audioaddons =None #line:1021
sources =None #line:1022
local =None #line:1023
try :#line:1024
        url =O0OO0OOOOO0000000 .unquote_plus (params ["url"])#line:1025
except :#line:1026
        pass #line:1027
try :#line:1028
        guisettingslink =O0OO0OOOOO0000000 .unquote_plus (params ["guisettingslink"])#line:1029
except :#line:1030
        pass #line:1031
try :#line:1032
        name =O0OO0OOOOO0000000 .unquote_plus (params ["name"])#line:1033
except :#line:1034
        pass #line:1035
try :#line:1036
        iconimage =O0OO0OOOOO0000000 .unquote_plus (params ["iconimage"])#line:1037
except :#line:1038
        pass #line:1039
try :#line:1040
        fanart =O0OO0OOOOO0000000 .unquote_plus (params ["fanart"])#line:1041
except :#line:1042
        pass #line:1043
try :#line:1044
        mode =str (params ["mode"])#line:1045
except :#line:1046
        pass #line:1047
try :#line:1048
        link =O0OO0OOOOO0000000 .unquote_plus (params ["link"])#line:1049
except :#line:1050
        pass #line:1051
try :#line:1052
        skins =O0OO0OOOOO0000000 .unquote_plus (params ["skins"])#line:1053
except :#line:1054
        pass #line:1055
try :#line:1056
        videoaddons =O0OO0OOOOO0000000 .unquote_plus (params ["videoaddons"])#line:1057
except :#line:1058
        pass #line:1059
try :#line:1060
        audioaddons =O0OO0OOOOO0000000 .unquote_plus (params ["audioaddons"])#line:1061
except :#line:1062
        pass #line:1063
try :#line:1064
        programaddons =O0OO0OOOOO0000000 .unquote_plus (params ["programaddons"])#line:1065
except :#line:1066
        pass #line:1067
try :#line:1068
        pictureaddons =O0OO0OOOOO0000000 .unquote_plus (params ["pictureaddons"])#line:1069
except :#line:1070
        pass #line:1071
try :#line:1072
        local =O0OO0OOOOO0000000 .unquote_plus (params ["local"])#line:1073
except :#line:1074
        pass #line:1075
try :#line:1076
        sources =O0OO0OOOOO0000000 .unquote_plus (params ["sources"])#line:1077
except :#line:1078
        pass #line:1079
try :#line:1080
        adult =O0OO0OOOOO0000000 .unquote_plus (params ["adult"])#line:1081
except :#line:1082
        pass #line:1083
try :#line:1084
        buildname =O0OO0OOOOO0000000 .unquote_plus (params ["buildname"])#line:1085
except :#line:1086
        pass #line:1087
try :#line:1088
        updated =O0OO0OOOOO0000000 .unquote_plus (params ["updated"])#line:1089
except :#line:1090
        pass #line:1091
try :#line:1092
        version =O0OO0OOOOO0000000 .unquote_plus (params ["version"])#line:1093
except :#line:1094
        pass #line:1095
try :#line:1096
        author =O0OO0OOOOO0000000 .unquote_plus (params ["author"])#line:1097
except :#line:1098
        pass #line:1099
try :#line:1100
        description =O0OO0OOOOO0000000 .unquote_plus (params ["description"])#line:1101
except :#line:1102
        pass #line:1103
try :#line:1104
        video =O0OO0OOOOO0000000 .unquote_plus (params ["video"])#line:1105
except :#line:1106
        pass #line:1107
def DELETEIVUEDB ():#line:1108
    OO0O0O00OOO0OOO0O =O000OO00O00OOOO00 .path .join (O0OO0OOOOO000O00O .translatePath ('special://profile/addon_data/script.tvguidetecbox/'),'')#line:1109
    if O000OO00O00OOOO00 .path .exists (OO0O0O00OOO0OOO0O )==True :#line:1110
        for OO0O0O00OOOO00OO0 ,O0O000O00O0O00OO0 ,OO000OOO0OO0OO0OO in O000OO00O00OOOO00 .walk (OO0O0O00OOO0OOO0O ):#line:1111
            O000O0OO0OO000000 =0 #line:1112
            O000O0OO0OO000000 +=len (OO000OOO0OO0OO0OO )#line:1113
            if O000O0OO0OO000000 >0 :#line:1114
                O0OOOOO00O00OOO00 =O00O00OO0O0O0OO00 .Dialog ()#line:1115
                if O0OOOOO00O00OOO00 .yesno ("Delete IVUE database Files",str (O000O0OO0OO000000 )+" files found","Do you want to delete them?"):#line:1116
                    for O0OO0OOO0000OOOOO in OO000OOO0OO0OO0OO :#line:1117
                        O000OO00O00OOOO00 .unlink (O000OO00O00OOOO00 .path .join (OO0O0O00OOOO00OO0 ,O0OO0OOO0000OOOOO ))#line:1118
                    for O0OOO00O000OOOOOO in O0O000O00O0O00OO0 :#line:1119
                        O0O0O0O0O000000O0 .rmtree (O000OO00O00OOOO00 .path .join (OO0O0O00OOOO00OO0 ,O0OOO00O000OOOOOO ))#line:1120
            else :#line:1121
                pass #line:1122
    O0OOOOO00O00OOO00 =O00O00OO0O0O0OO00 .Dialog ()#line:1123
    O0OOOOO00O00OOO00 .ok ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Team[/COLOR] Maintenance","Database Files Removed, Please reload TV Guide","[COLOR yellow]Brought To You By [COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Team[/COLOR][/COLOR]")#line:1124
def WIZARD (O0O000000O0000000 ,O00OOOOO000O00O00 ,OOO0OOO0O0OOO0OOO ):#line:1125
    O0OO00OO00O0OO0OO =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('special://home/addons','packages'))#line:1126
    OOOOO00OOOOOOOOOO =O00O00OO0O0O0OO00 .DialogProgress ()#line:1127
    OOOOO00OOOOOOOOOO .create ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Wizard[/COLOR]","Downloading ",'','Please Wait')#line:1128
    OOO00OO0O0OOO000O =O000OO00O00OOOO00 .path .join (O0OO00OO00O0OO0OO ,O0O000000O0000000 +'.zip')#line:1129
    try :#line:1130
       O000OO00O00OOOO00 .remove (OOO00OO0O0OOO000O )#line:1131
    except :#line:1132
       pass #line:1133
    OOO00OO000O000O0O .download (O00OOOOO000O00O00 ,OOO00OO0O0OOO000O ,OOOOO00OOOOOOOOOO )#line:1134
    OO0O00O0OOOO00000 =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('special://','home'))#line:1135
    OO00O0OOO000O000O .sleep (2 )#line:1136
    OOOOO00OOOOOOOOOO .update (0 ,"","Extracting Zip Please Wait")#line:1137
    print ('=======================================')#line:1138
    print (OO0O00O0OOOO00000 )#line:1139
    print ('=======================================')#line:1140
    OOOO000O0O0OO0000 .all (OOO00OO0O0OOO000O ,OO0O00O0OOOO00000 ,OOOOO00OOOOOOOOOO )#line:1141
    O0OO000O00O0OOO0O =O00O00OO0O0O0OO00 .Dialog ()#line:1142
    O0OO000O00O0OOO0O .ok ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Wizard[/COLOR]","To save changes you now need to force close Kodi, Press OK to force close Kodi")#line:1143
    killxbmc ()#line:1144
def ADDONWIZARD (OO0O0000OOOO0O0OO ,O00O0OO0OOO0OO0O0 ,OOO0O0OO0O0OOOO00 ):#line:1145
    O00O0000OO000OO0O =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('special://home/addons','packages'))#line:1146
    OO00OO00OO0O0OOOO =O00O00OO0O0O0OO00 .DialogProgress ()#line:1147
    OO00OO00OO0O0OOOO .create ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Wizard[/COLOR]","Downloading ",'','Please Wait')#line:1148
    O0OO0000O0OO0OO0O =O000OO00O00OOOO00 .path .join (O00O0000OO000OO0O ,OO0O0000OOOO0O0OO +'.zip')#line:1149
    try :#line:1150
       O000OO00O00OOOO00 .remove (O0OO0000O0OO0OO0O )#line:1151
    except :#line:1152
       pass #line:1153
    OOO00OO000O000O0O .download (O00O0OO0OOO0OO0O0 ,O0OO0000O0OO0OO0O ,OO00OO00OO0O0OOOO )#line:1154
    O0O0O0O0O00000000 =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('special://','home'))#line:1155
    OO00O0OOO000O000O .sleep (2 )#line:1156
    OO00OO00OO0O0OOOO .update (0 ,"","Extracting Zip Please Wait")#line:1157
    print ('=======================================')#line:1158
    print (O0O0O0O0O00000000 )#line:1159
    print ('=======================================')#line:1160
    OOOO000O0O0OO0000 .all (O0OO0000O0OO0OO0O ,O0O0O0O0O00000000 ,OO00OO00OO0O0OOOO )#line:1161
    OOO000O0OO00O0O00 =O00O00OO0O0O0OO00 .Dialog ()#line:1162
    OOO000O0OO00O0O00 .ok ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Wizard[/COLOR]","Please restart kodi for changes To Take Effect","[COLOR yellow]Brought To You By [COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Team[/COLOR][/COLOR]")#line:1163
def DeletePackages (O00OO0OOOO0O0OO0O ):#line:1164
    print ('############################################################       DELETING PACKAGES             ###############################################################')#line:1165
    O0OOOOOOOO000OOO0 =O0OO0OOOOO000O00O .translatePath (O000OO00O00OOOO00 .path .join ('special://home/addons/packages',''))#line:1166
    try :#line:1167
        for OO00O0000OOO00000 ,O0OOO000OO0000O00 ,OOO00OOOOO0O0O0OO in O000OO00O00OOOO00 .walk (O0OOOOOOOO000OOO0 ):#line:1168
            O000OO00O00O0OOO0 =0 #line:1169
            O000OO00O00O0OOO0 +=len (OOO00OOOOO0O0O0OO )#line:1170
            if O000OO00O00O0OOO0 >0 :#line:1171
                O0000O0O0O0000O00 =O00O00OO0O0O0OO00 .Dialog ()#line:1172
                if O0000O0O0O0000O00 .yesno ("Delete Package Cache Files",str (O000OO00O00O0OOO0 )+" files found","Do you want to delete them?"):#line:1173
                    for O0OO0O0O0OOO0O00O in OOO00OOOOO0O0O0OO :#line:1174
                        O000OO00O00OOOO00 .unlink (O000OO00O00OOOO00 .path .join (OO00O0000OOO00000 ,O0OO0O0O0OOO0O00O ))#line:1175
                    for O000O0000000OOOO0 in O0OOO000OO0000O00 :#line:1176
                        O0O0O0O0O000000O0 .rmtree (O000OO00O00OOOO00 .path .join (OO00O0000OOO00000 ,O000O0000000OOOO0 ))#line:1177
                    O0000O0O0O0000O00 =O00O00OO0O0O0OO00 .Dialog ()#line:1178
                    O0000O0O0O0000O00 .ok ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Wizard[/COLOR]","Packages Successfuly Removed","[COLOR yellow]Brought To You By [COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Team[/COLOR][/COLOR]")#line:1179
    except :#line:1180
        O0000O0O0O0000O00 =O00O00OO0O0O0OO00 .Dialog ()#line:1181
        O0000O0O0O0000O00 .ok ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Team[/COLOR]","Sorry we were not able to remove Package Files","[COLOR yellow]Brought To You By [COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Team[/COLOR][/COLOR]")#line:1182
def deletecachefiles (O0O00O00O0000O0OO ):#line:1183
    print ('############################################################       DELETING STANDARD CACHE             ###############################################################')#line:1184
    O00000OO0OO0OOOO0 =O000OO00O00OOOO00 .path .join (O0OO0OOOOO000O00O .translatePath ('special://home'),'cache')#line:1185
    if O000OO00O00OOOO00 .path .exists (O00000OO0OO0OOOO0 )==True :#line:1186
        for OO0OOO0OOO0O00000 ,OO0OO0O00OO00O0O0 ,OOO0O0OOO0O0O000O in O000OO00O00OOOO00 .walk (O00000OO0OO0OOOO0 ):#line:1187
            O000000OO000000O0 =0 #line:1188
            O000000OO000000O0 +=len (OOO0O0OOO0O0O000O )#line:1189
            if O000000OO000000O0 >0 :#line:1190
                OOOOO0OOO0OOOOO00 =O00O00OO0O0O0OO00 .Dialog ()#line:1191
                if OOOOO0OOO0OOOOO00 .yesno ("Delete Cache Files",str (O000000OO000000O0 )+" files found","Do you want to delete them?"):#line:1192
                    for OO00O0O0OOOO00000 in OOO0O0OOO0O0O000O :#line:1193
                        try :#line:1194
                            O000OO00O00OOOO00 .unlink (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OO00O0O0OOOO00000 ))#line:1195
                        except :#line:1196
                            pass #line:1197
                    for OOOO000OO000O0OO0 in OO0OO0O00OO00O0O0 :#line:1198
                        try :#line:1199
                            O0O0O0O0O000000O0 .rmtree (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OOOO000OO000O0OO0 ))#line:1200
                        except :#line:1201
                            pass #line:1202
            else :#line:1203
                pass #line:1204
    if O0OO0OOOOO000O00O .getCondVisibility ('system.platform.ATV2'):#line:1205
        O0OO000O0OO00O0OO =O000OO00O00OOOO00 .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')#line:1206
        for OO0OOO0OOO0O00000 ,OO0OO0O00OO00O0O0 ,OOO0O0OOO0O0O000O in O000OO00O00OOOO00 .walk (O0OO000O0OO00O0OO ):#line:1207
            O000000OO000000O0 =0 #line:1208
            O000000OO000000O0 +=len (OOO0O0OOO0O0O000O )#line:1209
            if O000000OO000000O0 >0 :#line:1210
                OOOOO0OOO0OOOOO00 =O00O00OO0O0O0OO00 .Dialog ()#line:1211
                if OOOOO0OOO0OOOOO00 .yesno ("Delete ATV2 Cache Files",str (O000000OO000000O0 )+" files found in 'Other'","Do you want to delete them?"):#line:1212
                    for OO00O0O0OOOO00000 in OOO0O0OOO0O0O000O :#line:1213
                        O000OO00O00OOOO00 .unlink (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OO00O0O0OOOO00000 ))#line:1214
                    for OOOO000OO000O0OO0 in OO0OO0O00OO00O0O0 :#line:1215
                        O0O0O0O0O000000O0 .rmtree (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OOOO000OO000O0OO0 ))#line:1216
            else :#line:1217
                pass #line:1218
        OO00O00O00OOOO00O =O000OO00O00OOOO00 .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')#line:1219
        for OO0OOO0OOO0O00000 ,OO0OO0O00OO00O0O0 ,OOO0O0OOO0O0O000O in O000OO00O00OOOO00 .walk (OO00O00O00OOOO00O ):#line:1220
            O000000OO000000O0 =0 #line:1221
            O000000OO000000O0 +=len (OOO0O0OOO0O0O000O )#line:1222
            if O000000OO000000O0 >0 :#line:1223
                OOOOO0OOO0OOOOO00 =O00O00OO0O0O0OO00 .Dialog ()#line:1224
                if OOOOO0OOO0OOOOO00 .yesno ("Delete ATV2 Cache Files",str (O000000OO000000O0 )+" files found in 'LocalAndRental'","Do you want to delete them?"):#line:1225
                    for OO00O0O0OOOO00000 in OOO0O0OOO0O0O000O :#line:1226
                        O000OO00O00OOOO00 .unlink (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OO00O0O0OOOO00000 ))#line:1227
                    for OOOO000OO000O0OO0 in OO0OO0O00OO00O0O0 :#line:1228
                        O0O0O0O0O000000O0 .rmtree (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OOOO000OO000O0OO0 ))#line:1229
            else :#line:1230
                pass #line:1231
    O000OO0O000O000OO =O000OO00O00OOOO00 .path .join (O0OO0OOOOO000O00O .translatePath ('special://profile/addon_data/plugin.video.whatthefurk/cache'),'')#line:1232
    if O000OO00O00OOOO00 .path .exists (O000OO0O000O000OO )==True :#line:1233
        for OO0OOO0OOO0O00000 ,OO0OO0O00OO00O0O0 ,OOO0O0OOO0O0O000O in O000OO00O00OOOO00 .walk (O000OO0O000O000OO ):#line:1234
            O000000OO000000O0 =0 #line:1235
            O000000OO000000O0 +=len (OOO0O0OOO0O0O000O )#line:1236
            if O000000OO000000O0 >0 :#line:1237
                OOOOO0OOO0OOOOO00 =O00O00OO0O0O0OO00 .Dialog ()#line:1238
                if OOOOO0OOO0OOOOO00 .yesno ("Delete WTF Cache Files",str (O000000OO000000O0 )+" files found","Do you want to delete them?"):#line:1239
                    for OO00O0O0OOOO00000 in OOO0O0OOO0O0O000O :#line:1240
                        O000OO00O00OOOO00 .unlink (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OO00O0O0OOOO00000 ))#line:1241
                    for OOOO000OO000O0OO0 in OO0OO0O00OO00O0O0 :#line:1242
                        O0O0O0O0O000000O0 .rmtree (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OOOO000OO000O0OO0 ))#line:1243
            else :#line:1244
                pass #line:1245
    OOO00OO0O000000OO =O000OO00O00OOOO00 .path .join (O0OO0OOOOO000O00O .translatePath ('special://profile/addon_data/plugin.video.4od/cache'),'')#line:1246
    if O000OO00O00OOOO00 .path .exists (OOO00OO0O000000OO )==True :#line:1247
        for OO0OOO0OOO0O00000 ,OO0OO0O00OO00O0O0 ,OOO0O0OOO0O0O000O in O000OO00O00OOOO00 .walk (OOO00OO0O000000OO ):#line:1248
            O000000OO000000O0 =0 #line:1249
            O000000OO000000O0 +=len (OOO0O0OOO0O0O000O )#line:1250
            if O000000OO000000O0 >0 :#line:1251
                OOOOO0OOO0OOOOO00 =O00O00OO0O0O0OO00 .Dialog ()#line:1252
                if OOOOO0OOO0OOOOO00 .yesno ("Delete 4oD Cache Files",str (O000000OO000000O0 )+" files found","Do you want to delete them?"):#line:1253
                    for OO00O0O0OOOO00000 in OOO0O0OOO0O0O000O :#line:1254
                        O000OO00O00OOOO00 .unlink (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OO00O0O0OOOO00000 ))#line:1255
                    for OOOO000OO000O0OO0 in OO0OO0O00OO00O0O0 :#line:1256
                        O0O0O0O0O000000O0 .rmtree (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OOOO000OO000O0OO0 ))#line:1257
            else :#line:1258
                pass #line:1259
    OOOO00000OOO0000O =O000OO00O00OOOO00 .path .join (O0OO0OOOOO000O00O .translatePath ('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'),'')#line:1260
    if O000OO00O00OOOO00 .path .exists (OOOO00000OOO0000O )==True :#line:1261
        for OO0OOO0OOO0O00000 ,OO0OO0O00OO00O0O0 ,OOO0O0OOO0O0O000O in O000OO00O00OOOO00 .walk (OOOO00000OOO0000O ):#line:1262
            O000000OO000000O0 =0 #line:1263
            O000000OO000000O0 +=len (OOO0O0OOO0O0O000O )#line:1264
            if O000000OO000000O0 >0 :#line:1265
                OOOOO0OOO0OOOOO00 =O00O00OO0O0O0OO00 .Dialog ()#line:1266
                if OOOOO0OOO0OOOOO00 .yesno ("Delete BBC iPlayer Cache Files",str (O000000OO000000O0 )+" files found","Do you want to delete them?"):#line:1267
                    for OO00O0O0OOOO00000 in OOO0O0OOO0O0O000O :#line:1268
                        O000OO00O00OOOO00 .unlink (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OO00O0O0OOOO00000 ))#line:1269
                    for OOOO000OO000O0OO0 in OO0OO0O00OO00O0O0 :#line:1270
                        O0O0O0O0O000000O0 .rmtree (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OOOO000OO000O0OO0 ))#line:1271
            else :#line:1272
                pass #line:1273
    O00OO000OO0OO0000 =O000OO00O00OOOO00 .path .join (O0OO0OOOOO000O00O .translatePath ('special://profile/addon_data/script.module.simple.downloader'),'')#line:1274
    if O000OO00O00OOOO00 .path .exists (O00OO000OO0OO0000 )==True :#line:1275
        for OO0OOO0OOO0O00000 ,OO0OO0O00OO00O0O0 ,OOO0O0OOO0O0O000O in O000OO00O00OOOO00 .walk (O00OO000OO0OO0000 ):#line:1276
            O000000OO000000O0 =0 #line:1277
            O000000OO000000O0 +=len (OOO0O0OOO0O0O000O )#line:1278
            if O000000OO000000O0 >0 :#line:1279
                OOOOO0OOO0OOOOO00 =O00O00OO0O0O0OO00 .Dialog ()#line:1280
                if OOOOO0OOO0OOOOO00 .yesno ("Delete Simple Downloader Cache Files",str (O000000OO000000O0 )+" files found","Do you want to delete them?"):#line:1281
                    for OO00O0O0OOOO00000 in OOO0O0OOO0O0O000O :#line:1282
                        O000OO00O00OOOO00 .unlink (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OO00O0O0OOOO00000 ))#line:1283
                    for OOOO000OO000O0OO0 in OO0OO0O00OO00O0O0 :#line:1284
                        O0O0O0O0O000000O0 .rmtree (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OOOO000OO000O0OO0 ))#line:1285
            else :#line:1286
                pass #line:1287
    O000OO00O0O0O0O0O =O000OO00O00OOOO00 .path .join (O0OO0OOOOO000O00O .translatePath ('special://profile/addon_data/plugin.video.itv/Images'),'')#line:1288
    if O000OO00O00OOOO00 .path .exists (O000OO00O0O0O0O0O )==True :#line:1289
        for OO0OOO0OOO0O00000 ,OO0OO0O00OO00O0O0 ,OOO0O0OOO0O0O000O in O000OO00O00OOOO00 .walk (O000OO00O0O0O0O0O ):#line:1290
            O000000OO000000O0 =0 #line:1291
            O000000OO000000O0 +=len (OOO0O0OOO0O0O000O )#line:1292
            if O000000OO000000O0 >0 :#line:1293
                OOOOO0OOO0OOOOO00 =O00O00OO0O0O0OO00 .Dialog ()#line:1294
                if OOOOO0OOO0OOOOO00 .yesno ("Delete ITV Cache Files",str (O000000OO000000O0 )+" files found","Do you want to delete them?"):#line:1295
                    for OO00O0O0OOOO00000 in OOO0O0OOO0O0O000O :#line:1296
                        O000OO00O00OOOO00 .unlink (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OO00O0O0OOOO00000 ))#line:1297
                    for OOOO000OO000O0OO0 in OO0OO0O00OO00O0O0 :#line:1298
                        O0O0O0O0O000000O0 .rmtree (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OOOO000OO000O0OO0 ))#line:1299
            else :#line:1300
                pass #line:1301
    O0O0OO0O000OOO0OO =O000OO00O00OOOO00 .path .join (O0OO0OOOOO000O00O .translatePath ('special://home/temp'),'')#line:1302
    if O000OO00O00OOOO00 .path .exists (O0O0OO0O000OOO0OO )==True :#line:1303
        for OO0OOO0OOO0O00000 ,OO0OO0O00OO00O0O0 ,OOO0O0OOO0O0O000O in O000OO00O00OOOO00 .walk (O0O0OO0O000OOO0OO ):#line:1304
            O000000OO000000O0 =0 #line:1305
            O000000OO000000O0 +=len (OOO0O0OOO0O0O000O )#line:1306
            if O000000OO000000O0 >0 :#line:1307
                OOOOO0OOO0OOOOO00 =O00O00OO0O0O0OO00 .Dialog ()#line:1308
                if OOOOO0OOO0OOOOO00 .yesno ("Delete TEMP dir Cache Files",str (O000000OO000000O0 )+" files found","Do you want to delete them?"):#line:1309
                    for OO00O0O0OOOO00000 in OOO0O0OOO0O0O000O :#line:1310
                        O000OO00O00OOOO00 .unlink (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OO00O0O0OOOO00000 ))#line:1311
                    for OOOO000OO000O0OO0 in OO0OO0O00OO00O0O0 :#line:1312
                        O0O0O0O0O000000O0 .rmtree (O000OO00O00OOOO00 .path .join (OO0OOO0OOO0O00000 ,OOOO000OO000O0OO0 ))#line:1313
            else :#line:1314
                pass #line:1315
    OOOOO0OOO0OOOOO00 =O00O00OO0O0O0OO00 .Dialog ()#line:1316
    OOOOO0OOO0OOOOO00 .ok ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Wizard[/COLOR]"," All Cache Files Removed","[COLOR yellow]Brought To You By [COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Team[/COLOR][/COLOR]")#line:1317
def OPEN_URL (O00O0OO00OOO0OO00 ):#line:1318
    OOOO0OO0OOO000O0O =OO0OOOOO0000O0000 .Request (O00O0OO00OOO0OO00 )#line:1319
    OOOO0OO0OOO000O0O .add_header ('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')#line:1320
    OO0O0O0OO000OOO00 =OO0OOOOO0000O0000 .urlopen (OOOO0OO0OOO000O0O )#line:1321
    OO000000OOO0OO000 =OO0O0O0OO000OOO00 .read ()#line:1322
    OO0O0O0OO000OOO00 .close ()#line:1323
    return OO000000OOO0OO000 #line:1324
def killxbmc ():#line:1325
    OO0OOO0000O0O0OOO =O00O00OO0O0O0OO00 .Dialog ().yesno ('[COLOR=green]Force Close Kodi[/COLOR]','You are about to close Kodi','Would you like to continue?',nolabel ='No, Cancel',yeslabel ='[COLOR=green]Yes, Close[/COLOR]')#line:1326
    if OO0OOO0000O0O0OOO ==0 :#line:1327
        return #line:1328
    elif OO0OOO0000O0O0OOO ==1 :#line:1329
        pass #line:1330
    O0O000OOO0O0OO00O =platform ()#line:1331
    print ("Platform: ")+str (O0O000OOO0O0OO00O )#line:1332
    if O0O000OOO0O0OO00O =='osx':#line:1333
        print ("############   try osx force close  #################")#line:1334
        try :O000OO00O00OOOO00 .system ('killall -9 XBMC')#line:1335
        except :pass #line:1336
        try :O000OO00O00OOOO00 .system ('killall -9 Kodi')#line:1337
        except :pass #line:1338
        dialog .ok ("[COLOR=red][B]WARNING  !!![/COLOR][/B]","If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')#line:1339
    elif O0O000OOO0O0OO00O =='linux':#line:1340
        print ("############   try linux force close  #################")#line:1341
        try :O000OO00O00OOOO00 .system ('killall XBMC')#line:1342
        except :pass #line:1343
        try :O000OO00O00OOOO00 .system ('killall Kodi')#line:1344
        except :pass #line:1345
        try :O000OO00O00OOOO00 .system ('killall -9 xbmc.bin')#line:1346
        except :pass #line:1347
        try :O000OO00O00OOOO00 .system ('killall -9 kodi.bin')#line:1348
        except :pass #line:1349
        dialog .ok ("[COLOR=red][B]WARNING  !!![/COLOR][/B]","If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')#line:1350
    elif O0O000OOO0O0OO00O =='android':#line:1351
        print ("############   try android force close  #################")#line:1352
        try :O000OO00O00OOOO00 .system ('adb shell am force-stop org.xbmc.kodi')#line:1353
        except :pass #line:1354
        try :O000OO00O00OOOO00 .system ('adb shell am force-stop org.kodi')#line:1355
        except :pass #line:1356
        try :O000OO00O00OOOO00 .system ('adb shell am force-stop org.xbmc.xbmc')#line:1357
        except :pass #line:1358
        try :O000OO00O00OOOO00 .system ('adb shell am force-stop org.xbmc')#line:1359
        except :pass #line:1360
        dialog .ok ("[COLOR=red][B]WARNING  !!![/COLOR][/B]","Your system has been detected as Android, you ","[COLOR=yellow][B]MUST[/COLOR][/B] force close XBMC/Kodi. [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Pulling the power cable is the simplest method to force close.")#line:1361
    elif O0O000OOO0O0OO00O =='windows':#line:1362
        print ("############   try windows force close  #################")#line:1363
        try :#line:1364
            O000OO00O00OOOO00 .system ('@ECHO off')#line:1365
            O000OO00O00OOOO00 .system ('tskill XBMC.exe')#line:1366
        except :pass #line:1367
        try :#line:1368
            O000OO00O00OOOO00 .system ('@ECHO off')#line:1369
            O000OO00O00OOOO00 .system ('tskill Kodi.exe')#line:1370
        except :pass #line:1371
        try :#line:1372
            O000OO00O00OOOO00 .system ('@ECHO off')#line:1373
            O000OO00O00OOOO00 .system ('TASKKILL /im Kodi.exe /f')#line:1374
        except :pass #line:1375
        try :#line:1376
            O000OO00O00OOOO00 .system ('@ECHO off')#line:1377
            O000OO00O00OOOO00 .system ('TASKKILL /im XBMC.exe /f')#line:1378
        except :pass #line:1379
        dialog .ok ("[COLOR=red][B]WARNING  !!![/COLOR][/B]","If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")#line:1380
    else :#line:1381
        print ("############   try atv force close  #################")#line:1382
        try :O000OO00O00OOOO00 .system ('killall AppleTV')#line:1383
        except :pass #line:1384
        print ("############   try raspbmc force close  #################")#line:1385
        try :O000OO00O00OOOO00 .system ('sudo initctl stop kodi')#line:1386
        except :pass #line:1387
        try :O000OO00O00OOOO00 .system ('sudo initctl stop xbmc')#line:1388
        except :pass #line:1389
        dialog .ok ("[COLOR=red][B]WARNING  !!![/COLOR][/B]","If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","Your platform could not be detected so just pull the power cable.")#line:1390
def platform ():#line:1391
    if O0OO0OOOOO000O00O .getCondVisibility ('system.platform.android'):#line:1392
        return 'android'#line:1393
    elif O0OO0OOOOO000O00O .getCondVisibility ('system.platform.linux'):#line:1394
        return 'linux'#line:1395
    elif O0OO0OOOOO000O00O .getCondVisibility ('system.platform.windows'):#line:1396
        return 'windows'#line:1397
    elif O0OO0OOOOO000O00O .getCondVisibility ('system.platform.osx'):#line:1398
        return 'osx'#line:1399
    elif O0OO0OOOOO000O00O .getCondVisibility ('system.platform.atv2'):#line:1400
        return 'atv2'#line:1401
    elif O0OO0OOOOO000O00O .getCondVisibility ('system.platform.ios'):#line:1402
        return 'ios'#line:1403
def FRESHSTART (OOOOOO000O00OOOOO ):#line:1404
    if skin !="skin.confluence":#line:1405
        dialog .ok ('[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Wizard[/COLOR] ','Please switch to the default Confluence skin','before performing a wipe.','')#line:1406
        O0OO0OOOOO000O00O .executebuiltin ("ActivateWindow(appearancesettings)")#line:1407
        return #line:1408
    else :#line:1409
        OOOOOOO00OOO0O00O =O00O00OO0O0O0OO00 .Dialog ().yesno ("[COLOR=red]ABSOLUTELY CERTAIN?!!![/COLOR]",'Are you absolutely certain you want to wipe this install?','','All addons and settings will be completely wiped!',yeslabel ='[COLOR=red]Yes[/COLOR]',nolabel ='[COLOR=green]No[/COLOR]')#line:1410
    if OOOOOOO00OOO0O00O ==0 :#line:1411
        return #line:1412
    elif OOOOOOO00OOO0O00O ==1 :#line:1413
        dp .create ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Wizard[/COLOR]","Wiping Install",'','Please Wait')#line:1414
        try :#line:1415
            for O00O00O0O0OO000OO ,OOO0000OOOO00OO00 ,OOO0O00OOO0000OOO in O000OO00O00OOOO00 .walk (HOME ,topdown =True ):#line:1416
                OOO0000OOOO00OO00 [:]=[O0O000O0000O00000 for O0O000O0000O00000 in OOO0000OOOO00OO00 if O0O000O0000O00000 not in EXCLUDES ]#line:1417
                for OOO00OO0O0O0O000O in OOO0O00OOO0000OOO :#line:1418
                    try :#line:1419
                        O000OO00O00OOOO00 .remove (O000OO00O00OOOO00 .path .join (O00O00O0O0OO000OO ,OOO00OO0O0O0O000O ))#line:1420
                        O000OO00O00OOOO00 .rmdir (O000OO00O00OOOO00 .path .join (O00O00O0O0OO000OO ,OOO00OO0O0O0O000O ))#line:1421
                    except :pass #line:1422
                for OOO00OO0O0O0O000O in OOO0000OOOO00OO00 :#line:1423
                    try :O000OO00O00OOOO00 .rmdir (O000OO00O00OOOO00 .path .join (O00O00O0O0OO000OO ,OOO00OO0O0O0O000O ));O000OO00O00OOOO00 .rmdir (O00O00O0O0OO000OO )#line:1424
                    except :pass #line:1425
        except :pass #line:1426
    REMOVE_EMPTY_FOLDERS ()#line:1427
    REMOVE_EMPTY_FOLDERS ()#line:1428
    REMOVE_EMPTY_FOLDERS ()#line:1429
    REMOVE_EMPTY_FOLDERS ()#line:1430
    REMOVE_EMPTY_FOLDERS ()#line:1431
    REMOVE_EMPTY_FOLDERS ()#line:1432
    REMOVE_EMPTY_FOLDERS ()#line:1433
    dialog .ok ('[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Wizard[/COLOR]','Wipe Successful, please restart XBMC/Kodi for changes to take effect.','','')#line:1434
    killxbmc ()#line:1435
def IPCHECK (url ='http://www.iplocation.net/',inc =1 ):#line:1436
    O0OO00O0O00OO0000 =O0O00OOOO0OOO00OO .compile ("<td width='80'>(.+?)</td><td>(.+?)</td><td>(.+?)</td><td>.+?</td><td>(.+?)</td>").findall (net .http_GET (url ).content )#line:1437
    for O0O00OOO0OOOO00O0 ,O0OOOO00O0000OO00 ,OOOOO00000OOOOO0O ,OOOOO0OO0OOO00O0O in O0OO00O0O00OO0000 :#line:1438
        if inc <2 :OOOOO00OOO0OOO000 =O00O00OO0O0O0OO00 .Dialog ();OOOOO00OOO0OOO000 .ok ('[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Wizard[/COLOR]',"[B][COLOR gold]Your IP Address is: [/COLOR][/B] %s"%O0O00OOO0OOOO00O0 ,'[B][COLOR gold]Your IP is based in: [/COLOR][/B] %s'%OOOOO00000OOOOO0O ,'[B][COLOR gold]Your Service Provider is:[/COLOR][/B] %s'%OOOOO0OO0OOO00O0O )#line:1439
        inc =inc +1 #line:1440
def UPDATEREPO ():#line:1441
    O0OO0OOOOO000O00O .executebuiltin ('UpdateLocalAddons')#line:1442
    O0OO0OOOOO000O00O .executebuiltin ('UpdateAddonRepos')#line:1443
    OOOO00OO0OOO00OOO =O00O00OO0O0O0OO00 .Dialog ()#line:1444
    OOOO00OO0OOO00OOO .ok ("[COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Wizard[/COLOR]",'','                                 REFRESH SUCCESSFUL :)',"                          [COLOR yellow]Brought To You By [COLOR red][B]Daily[/B][/COLOR][COLOR white][B]Updates[/B][/COLOR] [COLOR blue]Team[/COLOR][/COLOR]")#line:1445
    return #line:1446
def REMOVE_EMPTY_FOLDERS ():#line:1447
    print ("########### Start Removing Empty Folders #########")#line:1448
    O000OOO000OO000O0 =0 #line:1449
    O0O0000O0O0OO0OOO =0 #line:1450
    for O0OOOOOO00000000O ,O00O0O0OOOO000O0O ,OOO0000OOO0000O0O in O000OO00O00OOOO00 .walk (HOME ):#line:1451
        if len (O00O0O0OOOO000O0O )==0 and len (OOO0000OOO0000O0O )==0 :#line:1452
            O000OOO000OO000O0 +=1 #line:1453
            O000OO00O00OOOO00 .rmdir (O0OOOOOO00000000O )#line:1454
            print ("successfully removed: ")+O0OOOOOO00000000O #line:1455
        elif len (O00O0O0OOOO000O0O )>0 and len (OOO0000OOO0000O0O )>0 :#line:1456
            O0O0000O0O0OO0OOO +=1 #line:1457
def REMOVE_EMPTY_FOLDERS ():#line:1458
    print ("########### Start Removing Empty Folders #########")#line:1459
    OOOO00O000O00OOO0 =0 #line:1460
    OOOO00OOOOO0O00O0 =0 #line:1461
    for OOO0O0OO0OOOOO0OO ,OOOO0OO0O0000OOOO ,O0OOO000OO0O00O00 in O000OO00O00OOOO00 .walk (HOME ):#line:1462
        if len (OOOO0OO0O0000OOOO )==0 and len (O0OOO000OO0O00O00 )==0 :#line:1463
            OOOO00O000O00OOO0 +=1 #line:1464
            O000OO00O00OOOO00 .rmdir (OOO0O0OO0OOOOO0OO )#line:1465
            print ("successfully removed: ")+OOO0O0OO0OOOOO0OO #line:1466
        elif len (OOOO0OO0O0000OOOO )>0 and len (O0OOO000OO0O00O00 )>0 :#line:1467
            OOOO00OOOOO0O00O0 +=1 #line:1468
def get_params ():#line:1469
        O00O00O00000O00OO =[]#line:1470
        OO00OOOO00OOO0000 =OO0000OO0OO00OO0O .argv [2 ]#line:1471
        if len (OO00OOOO00OOO0000 )>=2 :#line:1472
                O0O0O0O000OO0OOO0 =OO0000OO0OO00OO0O .argv [2 ]#line:1473
                OO0O000O00O00OO0O =O0O0O0O000OO0OOO0 .replace ('?','')#line:1474
                if (O0O0O0O000OO0OOO0 [len (O0O0O0O000OO0OOO0 )-1 ]=='/'):#line:1475
                        O0O0O0O000OO0OOO0 =O0O0O0O000OO0OOO0 [0 :len (O0O0O0O000OO0OOO0 )-2 ]#line:1476
                O00OOO000OOO0O0O0 =OO0O000O00O00OO0O .split ('&')#line:1477
                O00O00O00000O00OO ={}#line:1478
                for O0OO0OOO0O0O00000 in range (len (O00OOO000OOO0O0O0 )):#line:1479
                        O000OOOOOO0O0O0OO ={}#line:1480
                        O000OOOOOO0O0O0OO =O00OOO000OOO0O0O0 [O0OO0OOO0O0O00000 ].split ('=')#line:1481
                        if (len (O000OOOOOO0O0O0OO ))==2 :#line:1482
                                O00O00O00000O00OO [O000OOOOOO0O0O0OO [0 ]]=O000OOOOOO0O0O0OO [1 ]#line:1483
        return O00O00O00000O00OO #line:1484
N =OO00OOOOO0O000OO0 .decodestring ('')#line:1485
T =OO00OOOOO0O000OO0 .decodestring ('L2FkZG9ucy50eHQ=')#line:1486
B =OO00OOOOO0O000OO0 .decodestring ('')#line:1487
F =OO00OOOOO0O000OO0 .decodestring ('')#line:1488
def addDir (O0OOO0O0O0O00OOO0 ,O0OO0O00O000O0OOO ,OOOOOO0OOO000O000 ,O00O000000O0O00O0 ,O00O0OOOO00O0OOO0 ,OOO00O000OO0OO0O0 ):#line:1489
        O0OOO000O000OO000 =OO0000OO0OO00OO0O .argv [0 ]+"?url="+O0OO0OOOOO0000000 .quote_plus (O0OO0O00O000O0OOO )+"&mode="+str (OOOOOO0OOO000O000 )+"&name="+O0OO0OOOOO0000000 .quote_plus (O0OOO0O0O0O00OOO0 )+"&iconimage="+O0OO0OOOOO0000000 .quote_plus (O00O000000O0O00O0 )+"&fanart="+O0OO0OOOOO0000000 .quote_plus (O00O0OOOO00O0OOO0 )+"&description="+O0OO0OOOOO0000000 .quote_plus (OOO00O000OO0OO0O0 )#line:1490
        OOO0O00OO00OO00OO =True #line:1491
        O0O00O0O0000000O0 =O00O00OO0O0O0OO00 .ListItem (O0OOO0O0O0O00OOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =O00O000000O0O00O0 )#line:1492
        O0O00O0O0000000O0 .setInfo (type ="Video",infoLabels ={"Title":O0OOO0O0O0O00OOO0 ,"Plot":OOO00O000OO0OO0O0 })#line:1493
        O0O00O0O0000000O0 .setProperty ("Fanart_Image",O00O0OOOO00O0OOO0 )#line:1494
        if OOOOOO0OOO000O000 ==90 :#line:1495
            OOO0O00OO00OO00OO =OOOOO0000O00OOOOO .addDirectoryItem (handle =int (OO0000OO0OO00OO0O .argv [1 ]),url =O0OOO000O000OO000 ,listitem =O0O00O0O0000000O0 ,isFolder =False )#line:1496
        else :#line:1497
            OOO0O00OO00OO00OO =OOOOO0000O00OOOOO .addDirectoryItem (handle =int (OO0000OO0OO00OO0O .argv [1 ]),url =O0OOO000O000OO000 ,listitem =O0O00O0O0000000O0 ,isFolder =True )#line:1498
        return OOO0O00OO00OO00OO #line:1499
params =get_params ()#line:1500
url =None #line:1501
name =None #line:1502
mode =None #line:1503
iconimage =None #line:1504
fanart =None #line:1505
description =None #line:1506
try :#line:1507
        url =O0OO0OOOOO0000000 .unquote_plus (params ["url"])#line:1508
except :#line:1509
        pass #line:1510
try :#line:1511
        name =O0OO0OOOOO0000000 .unquote_plus (params ["name"])#line:1512
except :#line:1513
        pass #line:1514
try :#line:1515
        iconimage =O0OO0OOOOO0000000 .unquote_plus (params ["iconimage"])#line:1516
except :#line:1517
        pass #line:1518
try :#line:1519
        mode =int (params ["mode"])#line:1520
except :#line:1521
        pass #line:1522
try :#line:1523
        fanart =O0OO0OOOOO0000000 .unquote_plus (params ["fanart"])#line:1524
except :#line:1525
        pass #line:1526
try :#line:1527
        description =O0OO0OOOOO0000000 .unquote_plus (params ["description"])#line:1528
except :#line:1529
        pass #line:1530
print (str (PATH )+': '+str (VERSION ))#line:1531
print ("Mode: ")+str (mode )#line:1532
print ("URL: ")+str (url )#line:1533
print ("Name: ")+str (name )#line:1534
print ("IconImage: ")+str (iconimage )#line:1535
def setView (OO00000OO0O0O0OOO ,OOO000O000OO0OOO0 ):#line:1536
    if OO00000OO0O0O0OOO :#line:1537
        OOOOO0000O00OOOOO .setContent (int (OO0000OO0OO00OO0O .argv [1 ]),OO00000OO0O0O0OOO )#line:1538
    if ADDON .getSetting ('auto-view')=='true':#line:1539
        O0OO0OOOOO000O00O .executebuiltin ("Container.SetViewMode(%s)"%ADDON .getSetting (OOO000O000OO0OOO0 ))#line:1540
if mode ==None or url ==None or len (url )<1 :#line:1541
        INDEX ()#line:1542
elif mode ==20 :#line:1543
        BUILDMENU ()#line:1544
elif mode ==21 :#line:1545
        BUILDMENU2 ()#line:1546
elif mode ==30 :#line:1547
        MAINTENANCE ()#line:1548
elif mode ==4 :#line:1549
        deletecachefiles (url )#line:1550
elif mode ==90 :#line:1551
        WIZARD (name ,url ,description )#line:1552
elif mode ==6 :#line:1553
	FRESHSTART (params )#line:1554
elif mode ==7 :#line:1555
       DeletePackages (url )#line:1556
elif mode ==8 :#line:1557
       facebook ()#line:1558
elif mode ==9 :#line:1559
       donation ()#line:1560
elif mode ==10 :#line:1561
        ADDONWIZARD (name ,url ,description )#line:1562
elif mode ==11 :#line:1563
        DELETEIVUEDB ()#line:1564
elif mode ==50 :#line:1565
        CBTOOLS (id )#line:1566
elif mode ==60 :#line:1567
        BACKUP_OPTION ()#line:1568
elif mode ==80 :#line:1569
        print ("############   ADDITIONAL TOOLS  #################")#line:1570
        ADDITIONAL_TOOLS ()#line:1571
elif mode ==61 :#line:1572
        print ("############   COMMUNITY BACKUP  #################")#line:1573
        COMMUNITY_BACKUP ()#line:1574
elif mode ==64 :#line:1575
        print ("############   RESTORE_BACKUP_XML #################")#line:1576
        RESTORE_BACKUP_XML (name ,url ,description )#line:1577
elif mode ==70 :#line:1578
        print ("############   RESTORE_OPTION   #################")#line:1579
        RESTORE_OPTION ()#line:1580
elif mode ==62 :#line:1581
        print ("############   RESTORE_ZIP_FILE   #################")#line:1582
        RESTORE_ZIP_FILE (url )#line:1583
elif mode =='restore_community':#line:1584
        print ("############   RESTORE_COMMUNITY BUILD  #################")#line:1585
        RESTORE_COMMUNITY (name ,url ,video ,description ,skins ,guisettingslink )#line:1586
elif mode ==82 :#line:1587
        print ("############   WIPE XBMC   #################")#line:1588
        WipeXBMC ()#line:1589
elif mode =='description':#line:1590
        print ("############   BUILD DESCRIPTION   #################")#line:1591
        DESCRIPTION (name ,url ,buildname ,author ,version ,description ,updated ,skins ,videoaddons ,audioaddons ,programaddons ,pictureaddons ,sources ,adult )#line:1592
elif mode =='community_menu':#line:1593
        print ("############   BUILD COMMUNITY LIST   #################")#line:1594
        COMMUNITY_MENU (url )#line:1595
elif mode =='play_video':#line:1596
        print ("############   PLAY VIDEO   #################")#line:1597
        PLAYVIDEO (url )#line:1598
elif mode =='instructions':#line:1599
        print ("############   INSTRUCTIONS MENU   #################")#line:1600
        INSTRUCTIONS (url )#line:1601
elif mode =='instructions_1':#line:1602
        print ("############   SHOW INSTRUCTIONS 1   #################")#line:1603
        Instructions_1 ()#line:1604
elif mode =='instructions_2':#line:1605
        print ("############   SHOW INSTRUCTIONS 2   #################")#line:1606
        Instructions_2 ()#line:1607
elif mode =='instructions_3':#line:1608
        print ("############   SHOW INSTRUCTIONS 3   #################")#line:1609
        Instructions_3 ()#line:1610
elif mode =='instructions_4':#line:1611
        print ("############   SHOW INSTRUCTIONS 4   #################")#line:1612
        Instructions_4 ()#line:1613
elif mode =='instructions_5':#line:1614
        print ("############   SHOW INSTRUCTIONS 5   #################")#line:1615
        Instructions_5 ()#line:1616
elif mode =='instructions_6':#line:1617
        print ("############   SHOW INSTRUCTIONS 6   #################")#line:1618
        Instructions_6 ()#line:1619
elif mode =='cb_root_menu':#line:1620
        print ("############   Daily Updates Builds Menu   #################")#line:1621
        CB_Root_Menu ()#line:1622
elif mode =='genres':#line:1623
        print ("############   Build GENRE1 Menu   #################")#line:1624
        GENRES ()#line:1625
elif mode =='countries':#line:1626
        print ("############   Build COUNTRIES Menu   #################")#line:1627
        COUNTRIES ()#line:1628
elif mode =='search_builds':#line:1629
        print ("############   MANUAL SEARCH BUILDS   #################")#line:1630
        SEARCH_BUILDS ()#line:1631
elif mode =='manual_search':#line:1632
        print ("############   MANUAL SEARCH BUILDS   #################")#line:1633
        MANUAL_SEARCH ()#line:1634
elif mode =='grab_builds':#line:1635
        print ("############   GRAB PUBLIC BUILDS   #################")#line:1636
        grab_builds (url )#line:1637
elif mode =='grab_builds_premium':#line:1638
        print ("############   GRAB PREMIUM BUILDS   #################")#line:1639
        grab_builds_premium (url )#line:1640
elif mode =='guisettingsfix':#line:1641
        print ("############   GUISETTINGS FIX   #################")#line:1642
        GUISETTINGS_FIX (url ,local )#line:1643
elif mode =='showinfo':#line:1644
        print ("############   SHOW BASIC BUILD INFO   #################")#line:1645
        SHOWINFO (url )#line:1646
elif mode ==81 :#line:1647
        print ("############   SHOW BASIC BUILD INFO   #################")#line:1648
        REMOVE_BUILD ()#line:1649
elif mode ==85 :#line:1650
        print ("############   ATTEMPT TO KILL XBMC/KODI   #################")#line:1651
        killxbmc ()#line:1652
elif mode ==83 :#line:1653
        print ("############   FIX SPECIAL PATHS   #################")#line:1654
        FIX_SPECIAL (url )#line:1655
elif mode ==71 :#line:1656
        print ("############   FIX SPECIAL PATHS   #################")#line:1657
        RESTORE_LOCAL_COMMUNITY ()#line:1658
elif mode =='restore_local_gui':#line:1659
        print ("############   FIX SPECIAL PATHS   #################")#line:1660
        RESTORE_LOCAL_GUI ()#line:1661
elif mode ==51 :#line:1662
        print ("############   Open Addon Settings   #################")#line:1663
        Addon_Settings ()#line:1664
elif mode ==72 :#line:1665
        print ("############   Open Local GUI dialog   #################")#line:1666
        LocalGUIDialog ()#line:1667
elif mode ==84 :#line:1668
        print ("############   Check Storage Location   #################")#line:1669
        O0OOOO00OO0000OO0 .CheckPath ()#line:1670
elif mode ==31 :#line:1671
        IPCHECK ()#line:1672
elif mode ==32 :#line:1673
        UPDATEREPO ()#line:1674
elif mode ==33 :#line:1675
        DELETETHUMBS ()#line:1676
elif mode ==40 :#line:1677
        APKDOWNMENU ()#line:1678
elif mode ==41 :#line:1679
        APKDOWNWIZ (name ,url ,description )#line:1680
OOOOO0000O00OOOOO .endOfDirectory (int (OO0000OO0OO00OO0O .argv [1 ]))#line:1681

#e9015584e6a44b14988f13e2298bcbf9


#===============================================================#
# Obfuscated by Oxyry Python Obfuscator (http://pyob.oxyry.com) #
#===============================================================#
