import xbmcaddon

MainBase = 'http://51.15.2.209/KingzHost/UrbanEmpire/XMLMain.xml'
addon = xbmcaddon.Addon('plugin.video.TheRealUrbanKingz')

