import xbmcaddon

MainBase = 'http://51.15.2.209/EntLeakz/XMLMain.xml'
addon = xbmcaddon.Addon('plugin.video.TheRealUrbanKingz')

