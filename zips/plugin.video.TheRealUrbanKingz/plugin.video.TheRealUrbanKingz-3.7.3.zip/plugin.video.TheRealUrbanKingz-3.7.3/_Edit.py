import xbmcaddon

MainBase = 'http://51.15.0.122/UrbanEmpire/UrbanEmpire/XMLMain.xml'
addon = xbmcaddon.Addon('plugin.video.TheRealUrbanKingz')

