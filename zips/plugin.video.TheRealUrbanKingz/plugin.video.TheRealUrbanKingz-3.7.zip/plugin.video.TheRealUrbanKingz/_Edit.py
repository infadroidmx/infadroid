import xbmcaddon

MainBase = 'http://therealurbankingz.com/GJKGJK/XMLMain.xml'
addon = xbmcaddon.Addon('plugin.video.TheRealUrbanKingz')