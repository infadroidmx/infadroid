import xbmcaddon

MainBase = 'http://13.58.227.165/files/urbankingz/XMLMain.xml'
addon = xbmcaddon.Addon('plugin.video.TheRealUrbanKingz')

