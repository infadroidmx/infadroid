import xbmcaddon

MainBase = 'http://urbankingz.srve.io/UrbanEmpire/XMLMain.xml'
addon = xbmcaddon.Addon('plugin.video.TheRealUrbanKingz')

