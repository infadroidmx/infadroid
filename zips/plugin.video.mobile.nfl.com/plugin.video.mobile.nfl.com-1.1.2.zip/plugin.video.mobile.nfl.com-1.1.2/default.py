#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib
import urllib2
import socket
import sys
import json
import xbmcplugin
import xbmcaddon
import xbmcgui
import uuid
import time
import datetime
import random
import requests
import re

socket.setdefaulttimeout(30)
pluginhandle = int(sys.argv[1])
addonID = 'plugin.video.mobile_nfl_com'
addon = xbmcaddon.Addon(id=addonID)
forceViewMode = addon.getSetting("forceViewMode") == "true"
viewMode = str(addon.getSetting("viewMode"))
agent = "okhttp/2.4.0"

dm = re.compile('(\d+)-(\d+)-(\d+)T(\d+):(\d+):(\d+).(\d+)([-+])(\d+):(\d+)')
def parseTime(intime):
  match= dm.findall(intime)[0]
  dt=datetime.datetime(int(match[0]),int(match[1]),int(match[2]),int(match[3]),int(match[4]),int(match[5]),int(match[6]))
  tz = datetime.timedelta(hours=int(match[8]),minutes=int(match[9]))
  if match[7]=="-":
    dt = dt + tz
  else:
    dt = dt - tz
  dt = dt - ( datetime.datetime.utcnow() - datetime.datetime.now() )
  #dt = dt + datetime.timedelta(hours=float(-4))
  return dt.strftime("%a %Y-%m-%d %H:%M")

def index():
    #get this week's games so we can label things properly
  if addon.getSetting("isVZW")=="true":
    chash=requests.get("https://api.nfl.com/v1/currentWeek",headers={"Authorization": authToken}).json()
    query = "%7B%22%24query%22%3A%7B%22week.season%22%3A"+str(chash["season"])+"%2C%22week.seasonType%22%3A%22"+chash["seasonType"]+"%22%2C%22week.week%22%3A"+str(chash["week"])+"%7D%7D&fs={week{season,seasonType,week},id,gameTime,gameStatus,homeTeam{id,abbr},visitorTeam{id,abbr},homeTeamScore,visitorTeamScore,networkChannel}"
    chash=requests.get("https://api.nfl.com/v1/games?s="+query,headers={"Authorization": authToken}).json()
    games = chash["data"]

    chash = requests.get("https://api.nfl.com/v1/geo/"+latitude+","+longitude,headers={"Authorization": authToken}).json()

    for gdata in games:
      found = False
      for game in chash["blacklist"]:
        if game['gameId']==gdata["id"]:
          status = "[COLOR=FF303030]Blacked Out "
          cstatus = "[/COLOR]"
          found = True
          continue
      for game in chash["whitelist"]:
        if game['gameId']==gdata["id"]:
          status = "[COLOR=FFF8F8F8] "
          cstatus = "[/COLOR]"
          found = True
          continue
      if found:
        addLink(status+gdata["visitorTeam"]["abbr"]+"@"+gdata["homeTeam"]["abbr"]+" "+parseTime(gdata["gameTime"])+cstatus,gdata['id'],"playGame",None)

  chash=requests.get("https://api.nfl.com/v1/config/?c=/public/android",headers={"Authorization": authToken}).json()
  for key, value in chash.iteritems():
    if key[:10]=="broadcast.":
      if key=="broadcast.nflredzone":
        addLink(key,value,"playGame",None)
      else:
        addLink(key,value,"playBroadcast",None)

  chash = requests.get("http://feeds.nfl.com/feeds-rs/videos/channels.json").json()
  for category in chash["videoChannelCategories"]:
    addDir(category["categoryName"],category["categoryId"],"listCategory","");
  xbmcplugin.endOfDirectory(pluginhandle)
  if forceViewMode:
    xbmc.executebuiltin('Container.SetViewMode('+viewMode+')')

def listCategory(categoryId):
  chash = requests.get("http://feeds.nfl.com/feeds-rs/videos/channels.json").json()
  for category in chash["videoChannelCategories"]:
    if category["categoryId"] != categoryId:
      continue;
    if len(category["videoChannels"])==1:
      listChannel(category["videoChannels"][0]["channelId"])
      return
    for channel in category["videoChannels"]:
      addDir(channel["channelName"],channel["channelId"],"listChannel", "")
  xbmcplugin.endOfDirectory(pluginhandle)
  if forceViewMode:
    xbmc.executebuiltin('Container.SetViewMode('+viewMode+')')

def getAuthToken():
    now=int(time.time())
    authexpire = addon.getSetting("authexpire")
    if authexpire:
      authexpire=int(authexpire)
    else:
      authexpire=0
    if authexpire < now:
      post = "grant_type=client_credentials&client_id=wvGfFADouuqzdtWivWVGui7T0U45UPf0&client_secret=Znk3ojvgU19J2tl0OX9hvhaKB1Td7aZ6&device_id="+myuuid
      #post = "grant_type=client_credentials&client_id=dyZHpNCWN5iuPx1gdbE3Dx9JAJIzZSCQ&client_secret=abD8E45RS31lZIHZhqoev5Zr78JO8j4W&device_id="+myuuid

      #requests post on ssl is broke in kodi, using urllib2 instead
      #chash = requests.post("https://api.nfl.com/v1/oauth/token",data=post).json()
      req = urllib2.Request("https://api.nfl.com/v1/oauth/token",post)
      response = urllib2.urlopen(req)
      link = response.read()
      response.close()
      chash = json.loads(link)

      addon.setSetting("authtoken",str(chash["access_token"]))
      addon.setSetting("authexpire",str(now+chash["expires_in"]))
      if addon.getSetting("isVZW")=="true":
        #authorize this session for verizon content
        json_data = {"token":myuuid}
        requests.put("https://api.nfl.com/v1/verizon/users/auth", data=json.dumps(json_data),headers={'Authorization':str(chash["access_token"]),'Content-Type':'application/json'})
    return "Bearer "+str(addon.getSetting("authtoken"))
      
def playBroadcast(url):
    query="%7B%22%24query%22%3A%7B%22id%22%3A%22"+url+"%22%7D%7D&fs=%20%7Bid%2CstreamUrl%2Cpresentation%7Btitle%2Ccapture%7D%2Ctype%7D"
    bhash=requests.get("https://api.nfl.com/v1/objects?s="+query,headers={"Authorization": authToken}).json()
    playVideo(bhash[url]["streamUrl"])

def playGame(url):
    #json_data = {"token":myuuid}
    #r = requests.put("https://api.nfl.com/v1/verizon/users/auth", data=json.dumps(json_data),headers={'Authorization':authToken,'Content-Type':'application/json'})
    #ghash = requests.get("https://api.nfl.com/v1/urls/"+url+'?latlong='+latitude+"%2C"+longitude+"&deviceId="+myuuid,headers={'NFL_GEO_COUNTRY': 'US',"Authorization": authToken}).json()
    r = requests.get("https://api.nfl.com/v1/urls/"+url+'?latlong='+latitude+"%2C"+longitude+"&deviceId="+myuuid,headers={'NFL_GEO_COUNTRY': 'US',"Authorization": authToken})
    xbmc.log(r.content)
    xbmc.log(str(r.status_code))
    ghash = json.loads(r.content)
    #xbmcgui.Dialog().ok(addon.getAddonInfo('name'),str(ghash))
    if "errors" in ghash:
      error = ghash["errors"][0]["message"]
      if 'roles' in ghash["errors"][0]:
        error += ", need role(s): "+str(ghash["errors"][0]["roles"])
      xbmcgui.Dialog().ok(addon.getAddonInfo('name'),"Error: "+error)
    else:
      playVideo(ghash["url"])

def playVideo(url):
    listitem = xbmcgui.ListItem(path=url+"|User-Agent=\""+urllib.quote_plus(agent)+"\"")
    xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)

def listChannel(channel):
  chash = requests.get("http://feeds.nfl.com/feeds-rs/videos/byChannel/"+channel+".json?limit=1000").json()
  processVideos(chash["videos"])
  xbmcplugin.endOfDirectory(pluginhandle)
  if forceViewMode:
    xbmc.executebuiltin('Container.SetViewMode('+viewMode+')')

def processVideos(videos):
  for video in videos:
    if video["contentType"]!="VIDEO" or video["videoBitRates"] is None:
      continue
    title = video["briefHeadline"];
    featureId = video["id"]
    thumb = video["mediumImageUrl"]
    aired = datetime.datetime.fromtimestamp(int(video["originalPublishDate"])/1000).strftime("%H:%M %a %d %b %Y")
    infoLabels = {"title":["headline"],"duration":int(video["runTime"][4:5])+1,"aired":aired,"plot":video["caption"]}
    bigvid = None
    bigbt = -1
    for bitrate in video["videoBitRates"]:
      if bitrate["bitrate"] > bigbt:
        bigbt = bitrate["bitrate"]
        bigvid = bitrate
    addLink(title+" ("+video["runTime"][:-3]+")",bigvid["videoPath"] , 'playVideo', thumb, infoLabels=infoLabels)

def parameters_string_to_dict(parameters):
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict


def addLink(name, url, mode, iconimage, infoLabels=None):
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels=infoLabels)
    liz.setProperty('IsPlayable', 'true')
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
    return ok

def addDir(name, url, mode, iconimage):
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

myuuid = str(addon.getSetting("uuid"))
authToken=getAuthToken()

if not myuuid:
  myuuid = str(uuid.uuid4())
  addon.setSetting("uuid",myuuid)

zipcode = str(addon.getSetting("zipcode"))
if zipcode == str(addon.getSetting("zipcodeChecked")):
  latitude = str(addon.getSetting("lat"))
  longitude = str(addon.getSetting("long"))
else:
  #all this so users don't have to look up their lat & long and can just put their zip into the settings menu
  zipapikey="mrqEr2Tfe4j93pUoXESuURTXLcDO9Z4vrvaSx38L7rVaQPzOtrioicl4oZSyYX3p"
  chash=requests.get("https://www.zipcodeapi.com/rest/"+zipapikey+"/info.json/"+zipcode+"/degrees").json()
  latitude = str(chash["lat"])
  longitude = str(chash["lng"])
  addon.setSetting("lat",latitude);
  addon.setSetting("long",longitude);
  addon.setSetting("zipcodeChecked",zipcode);

params = parameters_string_to_dict(sys.argv[2])
mode = urllib.unquote_plus(params.get('mode', ''))
url = urllib.unquote_plus(params.get('url', ''))
name = urllib.unquote_plus(params.get('name', ''))

if mode == 'listVideos':
    listVideos(url)
elif mode == 'listCategory':
    listCategory(url)
elif mode == 'listChannel':
    listChannel(url)
elif mode == 'playBroadcast':
    playBroadcast(url)
elif mode == 'playGame':
    playGame(url)
elif mode == 'playVideo':
    playVideo(url)
else:
    index()

