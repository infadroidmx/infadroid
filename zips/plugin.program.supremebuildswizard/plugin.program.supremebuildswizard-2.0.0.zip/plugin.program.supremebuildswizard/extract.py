#
#      Copyright (C) 2016 James Stark   ( ][NT3L][G3NC][ )
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
##########################################################################

import zipfile,time,xbmcgui

def all(iiNT3LiiZiiP, iiNT3LiiDiiR, dp=None):
	if not dp:
		dp = xbmcgui.DialogProgress()
		dp.create("[COLOR ghostwhite]Extracting: [/COLOR]",'[COLOR firebrick]Supreme Builds Wizard[/COLOR]','','')

	return allWithProgress(iiNT3LiiZiiP, iiNT3LiiDiiR, dp)

def GetHumanReadable(size):
	suffixes=['B','KB','MB','GB','TB']
	suffixIndex = 0
	size = float(size)

	while size > 1024:
		suffixIndex += 1 #increment the index of the suffix
		size = size/1024.0 #apply the division

	return "%.2f %s"%(size,suffixes[suffixIndex])


def allWithProgress(iiNT3LiiZiiP, iiNT3LiiDiiR, dp):

	iiNT3LiiFiiL3 = zipfile.ZipFile(iiNT3LiiZiiP)
	iiNT3LiiTOTAL = len(iiNT3LiiFiiL3.namelist())
	iiNT3LiiCOUNT  = 0
	iiNT3LiiFSiiZ3 = 0
	Total=0

	for i in iiNT3LiiFiiL3.infolist():
		Total += i.file_size

	iiNT3LiiSPAC3 = GetHumanReadable(int(Total))

	try:
		for i in iiNT3LiiFiiL3.infolist():
			iiNT3LiiFSiiZ3 += i.file_size
			iiNT3LiiSiiZ3D = GetHumanReadable(int(iiNT3LiiFSiiZ3))
			iiNT3LiiCOUNT += 1
			iiNT3LiiP3RC3NT = iiNT3LiiCOUNT / float(iiNT3LiiTOTAL) * 100
			iiNT3LiiNAM3 = i.filename
			iiNT3LiiFiiL3D = '[COLOR ghostwhite]'+str(iiNT3LiiNAM3)+'[/COLOR]'
			iiNT3LiiETA = '[COLOR ghostwhite]Files:[/COLOR] [COLOR cyan]'+str(iiNT3LiiCOUNT)+'[/COLOR] [COLOR ghostwhite]of[/COLOR] [COLOR cyan]'+str(iiNT3LiiTOTAL)+'[/COLOR]'
			iiNT3LiiETA += '   [COLOR ghostwhite]Size:[/COLOR] [COLOR cyan]'+str(iiNT3LiiSiiZ3D)+'[/COLOR] [COLOR ghostwhite]of[/COLOR] [COLOR cyan]'+str(iiNT3LiiSPAC3)+'[/COLOR]'

			if dp.iscanceled():
				try:
					dp.close()
				except Exception, e:
					print str(e)
			else:
				dp.update(int(iiNT3LiiP3RC3NT),'[COLOR firebrick]Extracting[/COLOR]',iiNT3LiiFiiL3D,iiNT3LiiETA)
			iiNT3LiiFiiL3.extract(i, iiNT3LiiDiiR)
	except Exception, e:
		print str(e)
		return False

	return True
