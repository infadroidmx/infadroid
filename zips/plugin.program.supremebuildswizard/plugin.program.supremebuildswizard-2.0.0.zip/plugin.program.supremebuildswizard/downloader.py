import xbmcgui
import urllib,time


def download(url, dest, dp = None):
	if not dp:
		dp = xbmcgui.DialogProgress()
		dp.create("[COLOR ghostwhite]Downloading: [/COLOR]",'[COLOR firebrick]Supreme Builds Wizard[/COLOR]','','')
	dp.update(0)
	oneTime=time.time()
	urllib.urlretrieve(url, dest, lambda numblocks,blocksize,filesize: _pbhook(numblocks,blocksize,filesize,dp,oneTime))


def _pbhook(numblocks,blocksize,filesize,dp,oneTime):
	try:
		percent = min(numblocks * blocksize * 100 / filesize, 100)
		currently_downloaded = float(numblocks) * blocksize / (1024 * 1024)
		kbps_speed = numblocks * blocksize / (time.time() - oneTime)
		if kbps_speed > 0:
			eta = (filesize - numblocks * blocksize) / kbps_speed
		else:
			eta = 0
		kbps_speed = kbps_speed / 1024
		total = float(filesize) / (1024 * 1024)
		mblocksize = '[COLOR ghostwhite]Progress:[/COLOR] [COLOR cyan]%.02f MB[/COLOR] [COLOR ghostwhite]of[/COLOR] [COLOR cyan]%.02f MB[/COLOR]' % (currently_downloaded, total)
		theETA = '[COLOR ghostwhite]Speed:[/COLOR] [COLOR cyan]%.02f [/COLOR][COLOR ghostwhite]Kb/s[/COLOR]  ' % kbps_speed
		theETA += '  [COLOR ghostwhite]Eta:[/COLOR] [COLOR cyan]%02d:%02d[/COLOR]' % divmod(eta, 60)
		if dp.iscanceled():
			dp.close()
			raise Exception("Cancelled")
		else:
			dp.update(percent,"[COLOR firebrick]Downloading[/COLOR]",theETA, mblocksize)
	except:
		percent = 100
		dp.update(percent)
	if dp.iscanceled():
		dp.close()
		raise Exception("Cancelled")
